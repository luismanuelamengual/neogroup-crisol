/**
 * Spanish dictionary — the default language and the reference of the others
 * (see en.ts, whose shape must match this one). Keys are grouped by feature.
 * `{name}` placeholders are replaced by the params of `t(key, params)`; a
 * `{ one, other }` message is a plural chosen with `params.count`.
 */
export const es = {
  common: {
    cancel: 'Cancelar',
    close: 'Cerrar',
    loading: 'Cargando...'
  },
  sound: {
    title: 'Sonido',
    music: 'Música',
    effects: 'Efectos',
    mute: 'Silenciar todo'
  },
  nav: {
    myProfile: 'Mi perfil',
    logout: 'Cerrar sesión',
    mainMenu: 'Menú principal'
  },
  metadata: {
    mainMenu: 'Menú principal',
    world: 'El mundo',
    verifyEmail: 'Verificá tu email',
    register: 'Crear cuenta',
    forgotPassword: 'Recuperar contraseña',
    newPassword: 'Nueva contraseña',
    login: 'Ingresar',
    offline: 'Sin conexión',
    profile: 'Mi perfil',
    privacy: 'Política de privacidad',
    deleteAccount: 'Eliminar cuenta'
  },
  pwa: {
    description:
      'RPG de fantasía por turnos: explorá un mundo laberíntico, vencé jefes, rescatá a tus compañeros y bajá al Abismo.',
    installPrompt:
      'Instalá Crisol en tu celular y jugá en pantalla completa, con un ícono en tu pantalla de inicio como cualquier otro juego.',
    install: 'Instalar',
    offlineTitle: 'Sin señal',
    offlineText: 'Crisol necesita internet para esta pantalla. Revisá tu conexión y volvé a intentarlo.'
  },
  orientation: {
    title: 'Girá el teléfono',
    text: 'Crisol se juega en horizontal. Poné el teléfono de costado para seguir.',
    lock: 'Jugar en horizontal'
  },
  landing: {
    tagline: 'Aurenya se apaga. Rescatá a los portadores de la Llama y bajá al Abismo a enfrentar a Crisol.',
    playFree: 'Jugar gratis',
    steps: {
      explore: {
        title: 'Explorá',
        text: 'Más de mil puntos unidos por senderos, nueve biomas y una niebla que solo se disipa avanzando.'
      },
      fight: {
        title: 'Combatí',
        text: 'Batallas por turnos donde manda la velocidad: elegí ataques, especiales y objetivos con cuidado.'
      },
      rise: {
        title: 'Renacé',
        text: 'Cada vez que Crisol cae vuelve más fuerte: Nuevo Juego+ sin fin para seguir mejorando a tu equipo.'
      }
    }
  },
  auth: {
    email: 'Email',
    password: 'Contraseña',
    playerName: 'Nombre de jugador',
    lastName: 'Apellido',
    login: {
      title: 'Iniciar sesión',
      subtitle: '¿Dónde estás? Entrá y demostralo.',
      google: 'Continuar con Google',
      or: 'o',
      verified: 'Tu email fue verificado. Ya podés iniciar sesión.',
      passwordReset: 'Tu contraseña fue actualizada. Ya podés iniciar sesión.',
      invalidCredentials: 'Email o contraseña incorrectos (o la cuenta todavía no fue verificada)',
      submit: 'Ingresar',
      forgotPassword: '¿Olvidaste tu contraseña?',
      noAccount: '¿No tenés cuenta?',
      register: 'Registrate'
    },
    register: {
      title: 'Crear cuenta',
      verifyTitle: 'Verificá tu email',
      verifySent:
        'Te enviamos un enlace de verificación a {email}. Revisá tu bandeja de entrada y hacé clic para activar tu cuenta.',
      alreadyActivated: '¿Ya la activaste?',
      login: 'Ingresar',
      passwordHint: 'Mínimo 6 caracteres',
      repeatPassword: 'Repetir contraseña',
      passwordsMismatch: 'Las contraseñas no coinciden',
      passwordsMismatchDot: 'Las contraseñas no coinciden.',
      submit: 'Crear cuenta',
      haveAccount: '¿Ya tenés cuenta?'
    },
    forgot: {
      title: 'Recuperar contraseña',
      sent: 'Si existe una cuenta asociada a {email}, vas a recibir un correo con instrucciones para restablecer tu contraseña.',
      subtitle: 'Ingresá tu email y te enviamos un enlace para restablecer tu contraseña.',
      submit: 'Enviar enlace',
      back: 'Volver a ingresar'
    },
    reset: {
      title: 'Nueva contraseña',
      newPassword: 'Nueva contraseña',
      confirmPassword: 'Confirmar contraseña',
      submit: 'Guardar contraseña',
      requestNew: 'Pedir un enlace nuevo'
    },
    verify: {
      expiredTitle: 'Enlace vencido',
      expiredText:
        'El enlace de verificación expiró. Registrate nuevamente con el mismo email y te mandamos uno nuevo.',
      invalidTitle: 'Enlace inválido',
      invalidText: 'El enlace de verificación no es válido o ya fue utilizado.',
      title: 'Verificá tu email',
      text: 'Revisá tu bandeja de entrada y hacé clic en el enlace de verificación para activar tu cuenta.',
      registerAgain: 'Registrarme de nuevo'
    },
    resetInvalid: 'El enlace no es válido o ya fue utilizado.',
    goToLogin: 'Ir a ingresar',
    somethingWentWrong: 'Algo salió mal. Intentá de nuevo.',
    emails: {
      verifySubject: 'Activá tu cuenta de Crisol',
      resetSubject: 'Restablecer tu contraseña de Crisol',
      greeting: '¡Hola {name}!',
      verifyIntro: 'Gracias por sumarte a Crisol. Para activar tu cuenta y empezar a jugar, verificá tu email:',
      verifyAction: 'Verificar mi email',
      verifyFooter: 'El enlace es válido por {hours} horas. Si no creaste esta cuenta, ignorá este mensaje.',
      resetIntro: 'Recibimos una solicitud para restablecer la contraseña de tu cuenta de Crisol.',
      resetAction: 'Restablecer contraseña',
      resetFooter: 'El enlace es válido por {hours} hora. Si no pediste este cambio, ignorá este mensaje.'
    }
  },
  account: {
    profile: 'Mi perfil',
    playerNameTitle: 'Nombre de jugador',
    lastNameTitle: 'Apellido',
    nicknameTitle: 'Apodo',
    nicknameHint: 'Si tenés apodo, se muestra en lugar de tu nombre y apellido',
    save: 'Guardar',
    saved: '¡Perfil actualizado!',
    languageLabel: 'Idioma de la aplicación',
    delete: {
      section: 'Eliminar cuenta',
      description: 'Se borran tu cuenta, tu nombre de jugador, tu email y tu partida guardada. No se puede deshacer.',
      button: 'Eliminar mi cuenta',
      title: '¿Eliminar tu cuenta?',
      warning:
        'Se van a borrar para siempre tu cuenta y tu partida guardada, con todos tus personajes. Esto no se puede deshacer.',
      confirmWord: 'ELIMINAR',
      confirmLabel: 'Escribí {word} para confirmar',
      confirm: 'Eliminar para siempre'
    }
  },
  legal: {
    privacyLink: 'Política de privacidad',
    updatedAt: 'Última actualización: {date}',
    privacy: {
      title: 'Política de privacidad',
      intro:
        'Crisol es un juego de rol de fantasía por turnos para un jugador. Esta política explica qué datos guardamos, para qué los usamos y cómo podés borrarlos.',
      data: {
        title: 'Qué datos guardamos',
        text: 'Al crear tu cuenta: tu email, tu nombre de jugador y tu contraseña (guardada cifrada, nunca en texto plano). Si entrás con Google, recibimos de Google tu email y tu nombre. También guardamos el idioma que elegís y tu partida guardada: tus personajes, tu avance en el mapa, tus objetos y tu tiempo de juego.'
      },
      use: {
        title: 'Para qué los usamos',
        text: 'Solo para que el juego funcione: iniciar sesión, guardar tu partida para que la continúes en cualquier dispositivo, y mandarte los emails de verificación de cuenta y de recuperación de contraseña. No vendemos tus datos.'
      },
      thirdParties: {
        title: 'Servicios de terceros',
        text: 'Usamos Google para el inicio de sesión con Google y las estadísticas de uso de la app (Google Analytics a través de Google Tag Manager); Vercel para alojar la aplicación; un proveedor de bases de datos PostgreSQL para guardar los datos; y Resend para enviar los emails. Cada uno trata los datos según su propia política de privacidad.'
      },
      storage: {
        title: 'Cookies y almacenamiento',
        text: 'Usamos una cookie para mantener tu sesión iniciada y otra para recordar tu idioma. El almacenamiento local del navegador guarda una copia de tu partida para poder jugar sin conexión y preferencias del dispositivo, como haber cerrado el aviso de instalación.'
      },
      retention: {
        title: 'Cuánto tiempo los guardamos',
        text: 'Tu cuenta y tu partida guardada se conservan hasta que las elimines. Empezar una partida nueva reemplaza la anterior.'
      },
      deletion: {
        title: 'Cómo borrar tus datos',
        text: 'Podés eliminar tu cuenta cuando quieras desde Mi perfil → Eliminar cuenta: se borran tu cuenta y tu partida guardada en el momento. Si no podés entrar, escribinos a {email} desde el email de tu cuenta y la borramos nosotros.'
      },
      security: {
        title: 'Seguridad',
        text: 'Toda la comunicación con Crisol viaja cifrada (HTTPS) y las contraseñas se guardan con un hash seguro (bcrypt).'
      },
      children: {
        title: 'Menores',
        text: 'Crisol no está dirigido a menores de 13 años y no recolectamos a sabiendas datos de menores de esa edad. Si creés que un menor nos dio sus datos, escribinos a {email} y los borramos.'
      },
      changes: {
        title: 'Cambios y contacto',
        text: 'Si cambiamos esta política, vamos a actualizar la fecha de arriba. Para cualquier consulta sobre tus datos escribinos a {email}.'
      }
    },
    deleteAccount: {
      title: 'Eliminar tu cuenta de Crisol',
      intro: 'Podés eliminar tu cuenta y todos tus datos desde la app, en cualquier momento:',
      steps: {
        signIn: 'Entrá a Crisol con tu cuenta.',
        profile: 'Abrí el menú de tu jugador y elegí Mi perfil.',
        confirm: 'Tocá Eliminar mi cuenta y confirmá escribiendo ELIMINAR.'
      },
      whatTitle: 'Qué se borra',
      whatText:
        'Se borran en el momento y para siempre tu cuenta (email, nombre de jugador y contraseña) y tu partida guardada, con todos tus personajes. No guardamos ninguna copia.',
      noAccessTitle: '¿No podés entrar?',
      noAccessText: 'Escribinos a {email} desde el email de tu cuenta pidiendo que la borremos y lo hacemos nosotros.',
      goToProfile: 'Ir a Mi perfil'
    }
  },
  home: {
    tagline: 'Aurenya se apaga. Solo la Llama Primera puede detener a Crisol.',
    continue: 'Continuar',
    newGame: 'Nuevo',
    cycle: 'NG+{cycle}',
    saveCharacters: { one: '{count} personaje', other: '{count} personajes' },
    saveLevel: 'Nivel {level}',
    newGameConfirm: {
      title: '¿Empezar una partida nueva?',
      text: 'Se borra tu partida guardada, con todos tus personajes y su avance. No se puede deshacer.',
      confirm: 'Empezar de nuevo'
    }
  },
  world: {
    nextCycle: {
      title: '¿Empezar el Nuevo Juego+ {cycle}?',
      kept: 'Tus personajes conservan todo: niveles, habilidades, armas, runas, ecos y Ecos, Lágrimas del Olvido y el bestiario.',
      lost: 'El mundo vuelve a empezar en el Claro del Despertar: vuelven la niebla, los campamentos, los jefes, los santuarios y los cofres, y se pierden el oro, las pociones y las piedras. Los enemigos son mucho más fuertes, y dan más experiencia y oro.',
      confirm: 'Empezar NG+{cycle}',
      started: 'Empieza el Nuevo Juego+ {cycle}. Aurenya vuelve a apagarse.'
    },
    title: 'Aurenya',
    level: 'Nivel {level}',
    levelShort: 'Nv. {level}',
    xp: 'XP {xp} de {next}',
    xpLabel: 'Experiencia: {xp} de {next}. Faltan {count} para el nivel {level}.',
    backToMenu: 'Volver al menú',
    menu: 'Menú',
    gold: 'Oro',
    missing: 'No tenés una partida guardada.',
    offlineNoCopy: 'Sin conexión, y este dispositivo no tiene una copia de tu partida.',
    camps: {
      start: 'Claro del Despertar',
      lair: 'Guarida de {name}',
      miniboss: 'Campamento {number} de {biome}'
    },
    biomes: {
      meadows: 'Praderas',
      forest: 'Bosques',
      tropical: 'Tropical',
      desert: 'Desiertos',
      mountains: 'Montañoso',
      snow: 'Nevado',
      volcanic: 'Volcánica',
      wastelands: 'Yermos',
      abyss: 'Abismo'
    },
    bosses: {
      morgrath: { name: 'Morgrath', title: 'Morgrath, la Bruja del Musgo' },
      sahrak: { name: 'Sahrak', title: 'Sahrak, el Rey Escorpión' },
      vorneth: { name: 'Vorneth', title: 'Vorneth, el Wyrm de Escarcha' },
      ignaroth: { name: 'Ignaroth', title: 'Ignaroth, Señor de la Ceniza' },
      xalqui: { name: 'Xalqui', title: 'Xalqui, la Serpiente de Jade' },
      colossus: { name: 'el Coloso', title: 'El Coloso de Basalto' },
      vael: { name: 'Vael', title: 'Vael, el Caballero Hueco' }
    },
    merchants: {
      peddler: 'Buhonero',
      alchemist: 'Alquimista',
      smith: 'Herrera',
      scholar: 'Erudito',
      threshold: 'Mercader del Umbral'
    },
    points: {
      combat: 'Combate',
      cleared: 'Camino despejado',
      respawned: 'Los enemigos volvieron',
      lostXp: '{xp} de experiencia perdida te espera aquí',
      miniboss: 'Minijefe de {biome}',
      sanctuary: 'Santuario de runa',
      sanctuaryTaken: 'Santuario (runa obtenida)',
      tear: 'Lágrima del Olvido',
      tearTaken: 'Lágrima del Olvido (obtenida)',
      amberFlask: 'Frasco de Ámbar',
      amberFlaskTaken: 'Frasco de Ámbar (obtenido)',
      amberEmber: 'Ascua de Ámbar',
      amberEmberTaken: 'Ascua de Ámbar (obtenida)',
      chest: 'Cofre',
      chestGuarded: 'Cofre custodiado',
      chestOpened: 'Cofre abierto',
      gate: 'Puerta del Abismo',
      gateSealed: { one: 'Sellada: falta {count} Sello', other: 'Sellada: faltan {count} Sellos' },
      crisol: 'Crisol',
      reliquary: 'Relicario de {weapon}',
      reliquaryTaken: 'Relicario ({weapon} obtenida)',
      reliquaryLocked: 'Solo {name} puede reclamar esta arma'
    },
    encounters: {
      combat: 'Combate',
      elite: 'Combate de élite',
      guardian: 'Guardián del santuario',
      warden: 'Guardián del relicario',
      miniboss: 'Minijefe',
      captor: 'Captor',
      seal: 'Sello del Abismo',
      gate: 'Guardián de la Puerta',
      crisol: 'Jefe final'
    },
    panel: {
      nextCycle: 'Nuevo Juego+ {cycle}',
      go: 'Ir',
      here: 'Estás acá',
      noRoute: 'Todavía no hay un camino despejado hasta acá.',
      rest: 'Descansar',
      rested:
        'Descansaste: el grupo y el Frasco se recuperaron. Los enemigos comunes vuelven a los 3 descansos de vencerlos.',
      teleport: 'Viajar',
      teleportTitle: 'Viajar a otro campamento',
      shop: 'Tienda'
    },
    flask: {
      name: 'Frasco de Ámbar',
      drink: 'Beber',
      heals: 'Cura el {potency}% de la vida a todo el grupo',
      empty: 'El Frasco está vacío: descansá en un campamento para llenarlo.',
      full: 'El grupo ya tiene la vida llena.'
    },
    rewards: {
      title: '¡Recompensa!',
      camp: '¡Campamento ganado: {name}!',
      character: '¡{name} se une al grupo en el nivel {level}!',
      flaskCharge: 'El Frasco de Ámbar ahora tiene {max} cargas',
      flaskPotency: 'El Frasco de Ámbar ahora cura el {potency}%',
      rune: 'Obtuviste la {name} ({tier})',
      item: '+{count} {name}',
      echoes: { one: 'Encontraste un Eco', other: 'Encontraste {count} Ecos' },
      tear: 'Encontraste una Lágrima del Olvido',
      weapon: '¡{name} obtuvo {weapon}!',
      gold: '+{amount} de oro',
      goldName: 'Oro',
      echoesName: { one: 'Eco', other: 'Ecos' },
      abyssOpen: 'Los dos Sellos cayeron: la Puerta del Abismo se abrió',
      crisol: '¡Crisol cayó! Terminá lo pendiente o empezá el Nuevo Juego+ desde cualquier campamento.'
    },
    runeTiers: {
      lesser: 'menor',
      greater: 'mayor',
      ancestral: 'ancestral',
      abyssal: 'abisal'
    },
    sync: {
      synced: 'Partida guardada',
      pending: 'Guardada en este dispositivo',
      syncing: 'Sincronizando...',
      offline: 'Sin conexión: guardada en este dispositivo',
      localDiscarded: 'Tu partida avanzó en otro dispositivo: se cargó esa versión.',
      serverDiscarded: 'Esta copia tenía más tiempo de juego que la de otro dispositivo: se mantuvo esta.'
    }
  },
  battle: {
    stances: { none: 'Sin postura', defense: 'Defensiva', offense: 'Ofensiva', virtuous: 'Virtuosa' },
    stancesShort: { none: 'Sin', defense: 'Def', offense: 'Ofe', virtuous: 'Vir' },
    stanceNeeds: 'Solo en postura {stances}',
    stanceTo: 'Pasa a postura {stance}',
    stanceDrop: 'Lo deja sin postura',
    special: 'Especial',
    turnOf: 'Turno de {name}',
    itemsLeft: { one: 'Te queda {count} objeto este turno', other: 'Te quedan {count} objetos este turno' },
    shields: { one: '{count} escudo', other: '{count} escudos' },
    shieldGain: { one: '+{count} escudo', other: '+{count} escudos' },
    shieldBlock: '¡Bloqueado!',
    tapEnemy: 'Tocá un enemigo',
    tapAlly: 'Tocá un aliado',
    reach: { enemy: 'Uno', allEnemies: 'Todos', ally: 'Aliado', allAllies: 'Grupo', self: 'Propio' },
    emptySlot: 'Libre',
    traits: {
      none: 'Sin postura',
      defense: 'Postura defensiva',
      offense: 'Postura ofensiva',
      virtuous: 'Postura virtuosa',
      fury: 'Furia {value}',
      charges: 'Cargas: {types}',
      marks: { one: '{count} marca', other: '{count} marcas' }
    },
    items: 'Objetos',
    noItems: 'No hay objetos para usar',
    chooseAlly: 'Elegí un aliado',
    attack: 'Atacar',
    specials: 'Especiales',
    retreat: 'Retirarse',
    retreatBlocked: 'Solo podés retirarte con todos los héroes en pie',
    chooseTarget: 'Elegí un objetivo',
    back: 'Volver',
    focusCost: '{cost} conc.',
    focus: 'Conc.',
    speed: 'Velocidad ×{speed}',
    phase: 'Fase {phase} de {total}',
    enemyTurn: 'Turno enemigo',
    weak: '¡Débil!',
    resist: 'Resiste',
    immune: 'Inmune',
    miss: 'Falla',
    transform: '¡Se transforma!',
    victory: '¡Victoria!',
    defeat: 'Tu grupo cayó',
    defeatText: 'Perdés toda la experiencia de tu nivel actual y despertás en el último campamento donde descansaste.',
    retreated: 'Te retiraste',
    retreatText: 'Volvés al punto anterior sin perder experiencia.',
    xpGained: '+{xp} de experiencia',
    xpRecovered: '+{xp} de experiencia recuperada',
    xpLeftBehind: 'Lo que perdiste quedó en este lugar: vencé a estos enemigos para recuperarlo.',
    xpForfeited: 'La experiencia que habías dejado en tu caída anterior ({xp}) se perdió.',
    levelUp: '{name} sube al nivel {level}',
    levelUpShort: '¡Nivel {level}!',
    continue: 'Continuar',
    elite: '{name} de élite'
  },
  statuses: {
    poison: 'Veneno',
    burn: 'Quemadura',
    bleed: 'Sangrado',
    freeze: 'Congelado',
    stun: 'Aturdido',
    blind: 'Ceguera',
    attackUp: 'Ataque ▲',
    attackDown: 'Ataque ▼',
    defenseUp: 'Defensa ▲',
    defenseDown: 'Defensa ▼',
    speedUp: 'Velocidad ▲',
    speedDown: 'Velocidad ▼',
    critUp: 'Crítico ▲',
    regen: 'Regeneración',
    ward: 'Protección',
    imbueFire: 'Arma de fuego',
    imbueIce: 'Arma de hielo',
    imbueLightning: 'Arma de rayo',
    imbueEarth: 'Arma de tierra',
    imbueLight: 'Arma de luz',
    imbueDarkness: 'Arma de sombra',
    imbueVenom: 'Arma envenenada'
  },
  skills: {
    'kael-strike': 'Tajo',
    'kael-firm-cut': 'Corte Firme',
    'kael-flame-edge': 'Filo de Llama',
    'kael-sweep': 'Barrido',
    'kael-guard': 'Guardia',
    'sera-shot': 'Disparo',
    'sera-piercing-arrow': 'Flecha Perforante',
    'sera-volley': 'Andanada',
    'sera-blinding-arrow': 'Flecha Cegadora',
    'brann-chop': 'Hachazo',
    'brann-cleave': 'Tajo Brutal',
    'brann-earthsplitter': 'Parte Tierra',
    'brann-roar': 'Rugido',
    'oren-root-cut': 'Tajo de Raíz',
    'oren-mend': 'Savia',
    'oren-grove': 'Arboleda',
    'oren-thorns': 'Espinas',
    'ysolde-seal-bolt': 'Saeta del Sello',
    'kael-dawn-cut': 'Tajo del Alba',
    'kael-mace-blow': 'Mazazo',
    'sera-frost-arrow': 'Flecha de Escarcha',
    'sera-gale-shot': 'Ráfaga',
    'brann-maul-smash': 'Golpe de Cantera',
    'brann-twin-cut': 'Doble Tajo',
    'oren-sun-reap': 'Siega Solar',
    'oren-sickle-cut': 'Última Siega',
    'ysolde-thunder-page': 'Página del Trueno',
    'ysolde-prism-ray': 'Haz Prismático',
    'ysolde-fireball': 'Bola de Fuego',
    'ysolde-frost-lance': 'Lanza de Escarcha',
    'ysolde-chain-lightning': 'Cadena de Rayos',
    claw: 'Zarpazo',
    gore: 'Cornada',
    bite: 'Mordida',
    lunge: 'Embestida',
    'venom-bite': 'Mordida Venenosa',
    rend: 'Desgarro',
    bash: 'Golpe',
    harden: 'Endurecer',
    peck: 'Picotazo',
    mend: 'Sanar',
    hex: 'Maleficio',
    slam: 'Sacudida',
    roar: 'Bramido',
    'fire-bolt': 'Saeta de Fuego',
    'fire-wave': 'Ola de Fuego',
    'ice-bolt': 'Saeta de Hielo',
    'ice-wave': 'Ventisca',
    'lightning-bolt': 'Rayo',
    'lightning-wave': 'Tormenta',
    'earth-bolt': 'Piedra',
    'earth-wave': 'Temblor',
    'light-bolt': 'Destello',
    'light-wave': 'Aurora',
    'darkness-bolt': 'Sombra Punzante',
    'darkness-wave': 'Marea Oscura',
    'kael-whirlwind': 'Torbellino',
    'kael-rally': 'Arenga',
    'kael-inferno': 'Infierno',
    'kael-execution': 'Ejecución',
    'kael-blade-dance': 'Danza de espadas',
    'kael-shield-bash': 'Golpe de escudo',
    'kael-last-bastion': 'Último bastión',
    'kael-phoenix-cut': 'Corte del fénix',
    'kael-sunfall': 'Caída del sol',
    'sera-aimed-shot': 'Disparo certero',
    'sera-heartseeker': 'Buscacorazones',
    'sera-hunters-mark': 'Marca del Cazador',
    'kael-riposte': 'Contragolpe',
    'kael-oath': 'Juramento',
    'kael-ember-slash': 'Tajo de brasas',
    'kael-sundering-blow': 'Golpe quebrantador',
    'kael-dawn-strike': 'Golpe del alba',
    'kael-war-banner': 'Estandarte',
    'kael-crimson-edge': 'Filo carmesí',
    'sera-quick-shot': 'Tiro rápido',
    'sera-poison-arrow': 'Flecha envenenada',
    'sera-shadow-step': 'Paso sombrío',
    'sera-thunder-arrow': 'Flecha de trueno',
    'sera-rain-of-arrows': 'Lluvia de flechas',
    'sera-eclipse-shot': 'Disparo eclipse',
    'sera-falcon-dive': 'Picada del halcón',
    'brann-headbutt': 'Cabezazo',
    'brann-bloodletting': 'Sangría',
    'brann-war-stomp': 'Pisotón',
    'brann-rallying-roar': 'Rugido de guerra',
    'brann-fury-cleave': 'Tajo furioso',
    'brann-magma-fist': 'Puño de magma',
    'brann-titan-grip': 'Agarre de titán',
    'oren-seed-shot': 'Semilla',
    'oren-sunbeam': 'Rayo de sol',
    'oren-verdant-aura': 'Aura verde',
    'oren-hemlock': 'Cicuta',
    'ysolde-ember': 'Ascua',
    'ysolde-ice-shards': 'Esquirlas de hielo',
    'ysolde-static-field': 'Campo estático',
    'ysolde-arcane-shield': 'Escudo arcano',
    'ysolde-fire-pillar': 'Pilar de fuego',
    'ysolde-glacial-spear': 'Lanza glacial',
    'sera-gale-arrow': 'Flecha vendaval',
    'sera-tailwind': 'Viento a favor',
    'sera-arrow-storm': 'Tormenta de flechas',
    'sera-hurricane': 'Huracán',
    'sera-toxic-cloud': 'Nube tóxica',
    'sera-crippling-shot': 'Disparo mutilador',
    'sera-night-volley': 'Andanada nocturna',
    'brann-rampage': 'Arrasar',
    'brann-berserk': 'Frenesí',
    'brann-carnage': 'Carnicería',
    'brann-world-breaker': 'Rompemundos',
    'brann-stone-skin': 'Piel de piedra',
    'brann-shield-wall': 'Muro de escudos',
    'brann-avalanche': 'Avalancha',
    'brann-boulder': 'Peñasco',
    'brann-hammerfall': 'Martillazo',
    'brann-cataclysm': 'Cataclismo',
    'oren-purify': 'Purificar',
    'oren-rejuvenate': 'Rejuvenecer',
    'oren-cleansing-rain': 'Lluvia purificadora',
    'oren-rebirth': 'Renacer',
    'oren-tree-of-life': 'Árbol de la vida',
    'oren-barkskin': 'Piel de corteza',
    'oren-blessing': 'Bendición',
    'oren-swiftwood': 'Madera ligera',
    'oren-sanctuary': 'Santuario',
    'oren-entangle': 'Enredar',
    'oren-poison-bloom': 'Flor venenosa',
    'oren-rot': 'Podredumbre',
    'oren-wild-growth': 'Crecimiento salvaje',
    'ysolde-flame-wave': 'Ola de llamas',
    'ysolde-combustion': 'Combustión',
    'ysolde-meteor': 'Meteoro',
    'ysolde-frost-armor': 'Armadura de escarcha',
    'ysolde-blizzard': 'Ventisca',
    'ysolde-frozen-tomb': 'Tumba helada',
    'ysolde-absolute-zero': 'Cero absoluto',
    'ysolde-spark': 'Chispa',
    'ysolde-convergence': 'Convergencia',
    'ysolde-thunderclap': 'Trueno',
    'ysolde-heavens-wrath': 'Ira del cielo',
    arrow: 'Flecha',
    sting: 'Aguijón',
    pounce: 'Abalanzarse',
    impale: 'Empalar',
    crush: 'Aplastar',
    web: 'Telaraña',
    'spore-cloud': 'Nube de esporas',
    sandstorm: 'Tormenta de arena',
    quake: 'Sismo',
    'frost-breath': 'Aliento helado',
    'fire-breath': 'Aliento de fuego',
    shriek: 'Chillido',
    curse: 'Maldición',
    'soul-drain': 'Drenar alma',
    smite: 'Castigo',
    'war-cry': 'Grito de guerra',
    bulwark: 'Baluarte',
    chorus: 'Coro',
    'entangle-roots': 'Raíces atrapadoras',
    'blood-howl': 'Aullido de sangre'
  },
  enemies: {
    'thorn-boar': 'Jabalí Espinado',
    'road-bandit': 'Bandido de Camino',
    'wheat-spirit': 'Espíritu del Trigo',
    'hedge-sprite': 'Duende del Seto',
    'shadow-wolf': 'Lobo Sombrío',
    'rotten-ent': 'Ent Podrido',
    'weaver-spider': 'Araña Tejedora',
    'jade-viper': 'Víbora de Jade',
    'fungal-shaman': 'Chamán Hongo',
    'toxic-frog': 'Rana Tóxica',
    'giant-scorpion': 'Escorpión Gigante',
    'wandering-mummy': 'Momia Errante',
    'sand-worm': 'Gusano de Arena',
    'rock-golem': 'Gólem de Roca',
    harpy: 'Harpía',
    'renegade-dwarf': 'Enano Renegado',
    yeti: 'Yeti',
    'frost-wolf': 'Lobo de Escarcha',
    'ice-wisp': 'Espíritu Helado',
    salamander: 'Salamandra',
    'magma-elemental': 'Elemental de Magma',
    'young-dragon': 'Dragón Joven',
    ghoul: 'Necrófago',
    'bone-knight': 'Caballero de Hueso',
    devourer: 'Devorador',
    'crucible-horror': 'Horror del Crisol',
    'castle-warden': 'Guardia del Castillo',
    'abyss-eye': 'Ojo del Abismo',
    'boar-matriarch': 'Matriarca Espinada',
    'bandit-chief': 'Jefe de los Bandidos',
    'wasp-queen': 'La Reina Avispa',
    morgrath: 'Morgrath, la Bruja del Musgo',
    sahrak: 'Sahrak, el Rey Escorpión',
    vorneth: 'Vorneth, el Wyrm de Escarcha',
    ignaroth: 'Ignaroth, Señor de la Ceniza',
    xalqui: 'Xalqui, la Serpiente de Jade',
    colossus: 'El Coloso de Basalto',
    vael: 'Vael, el Caballero Hueco',
    crisol: 'Crisol',
    'field-rat': 'Rata de campo',
    scarecrow: 'Espantapájaros',
    'meadow-wasp': 'Avispa del prado',
    'bandit-archer': 'Arquero bandido',
    'giant-toad': 'Sapo gigante',
    'thorn-dryad': 'Dríade espinosa',
    'bog-wight': 'Aparecido del pantano',
    'moss-bear': 'Oso de musgo',
    'forest-goblin': 'Trasgo del bosque',
    'cursed-stag': 'Ciervo maldito',
    'creeping-vine': 'Enredadera reptante',
    'jungle-panther': 'Pantera de la jungla',
    'giant-mosquito': 'Mosquito gigante',
    'carnivorous-plant': 'Planta carnívora',
    'lizard-warrior': 'Guerrero lagarto',
    'mangrove-croc': 'Cocodrilo del manglar',
    'tribal-witch': 'Bruja tribal',
    'dune-raider': 'Saqueador de dunas',
    'sun-priest': 'Sacerdote del sol',
    'desert-djinn': 'Genio del desierto',
    vulture: 'Buitre',
    'tomb-guardian': 'Guardián de la tumba',
    'scarab-swarm': 'Enjambre de escarabajos',
    'mountain-troll': 'Trol de montaña',
    'storm-eagle': 'Águila de tormenta',
    'crystal-sprite': 'Duendecillo de cristal',
    'dwarf-runepriest': 'Sacerdote rúnico enano',
    'cave-bat': 'Murciélago de cueva',
    'stone-basilisk': 'Basilisco de piedra',
    'snow-troll': 'Trol de las nieves',
    'ice-wraith': 'Espectro de hielo',
    'frost-giant': 'Gigante de escarcha',
    'polar-bear': 'Oso polar',
    'snow-harpy': 'Arpía de las nieves',
    'frozen-shaman': 'Chamán helado',
    'fire-imp': 'Diablillo de fuego',
    'lava-golem': 'Gólem de lava',
    'ash-wraith': 'Espectro de ceniza',
    hellhound: 'Sabueso infernal',
    'obsidian-knight': 'Caballero de obsidiana',
    'flame-priest': 'Sacerdote de la llama',
    banshee: 'Banshee',
    'plague-rat': 'Rata de la plaga',
    'grave-priest': 'Sacerdote de las tumbas',
    'hollow-archer': 'Arquero hueco',
    'flesh-golem': 'Gólem de carne',
    'carrion-crow': 'Cuervo carroñero',
    'abyssal-knight': 'Caballero abisal',
    'chaos-spawn': 'Engendro del caos',
    'void-weaver': 'Tejedor del vacío',
    'crucible-priest': 'Sacerdote del Crisol',
    'shadow-stalker': 'Acechador de sombras',
    'molten-horror': 'Horror fundido',
    'alpha-wolf': 'Colmillo Gris, el Alfa',
    'elder-treant': 'El Ent Anciano',
    'spider-queen': 'La Reina Araña',
    'mire-witch': 'La Bruja del Fango',
    'jaguar-king': 'El Rey Jaguar',
    'swamp-hydra': 'La Hidra del Pantano',
    'dune-wyrm': 'La Sierpe de las Dunas',
    'mummy-pharaoh': 'El Faraón Momia',
    'sand-titan': 'El Titán de Arena',
    'crystal-wyrm': 'La Sierpe de Cristal',
    'dwarf-warlord': 'El Señor de la Guerra Enano',
    'thunder-roc': 'El Roc del Trueno',
    'winter-witch': 'La Bruja del Invierno',
    'ice-troll-king': 'El Rey Trol de Hielo',
    'ancient-mammoth': 'El Mamut Ancestral',
    'fire-drake': 'El Draco de Fuego',
    'magma-behemoth': 'El Behemot de Magma',
    lich: 'El Liche',
    'bone-dragon': 'El Dragón de Hueso',
    'abyssal-champion': 'El Campeón Abisal',
    'crucible-maw': 'Las Fauces del Crisol',
    'old-scarecrow': 'El Viejo Espantapájaros',
    'moss-golem': 'El Gólem de Musgo',
    'temple-serpent': 'La Serpiente del Templo',
    sphinx: 'La Esfinge',
    'rune-golem': 'El Gólem Rúnico',
    'ember-sentinel': 'El Centinela de Brasas',
    phoenix: 'El Fénix',
    'frost-sentinel': 'El Centinela de Escarcha',
    'death-knight': 'El Caballero de la Muerte',
    'wraith-lord': 'El Señor de los Espectros',
    'void-sentinel': 'El Centinela del Vacío',
    'crucible-herald': 'El Heraldo del Crisol',
    'cinder-stag': 'El Ciervo de Ceniza',
    'shell-colossus': 'El Coloso de Caparazón',
    'glass-djinn': 'El Djinn de Cristal',
    'storm-harpy': 'La Arpía de la Tormenta',
    'granite-warden': 'El Celador de Granito',
    'frost-reaver': 'El Saqueador Gélido',
    'ashen-seraph': 'El Serafín Ceniciento',
    'thorn-widow': 'La Viuda de Espinas',
    'storm-revenant': 'El Aparecido de la Tormenta',
    'prism-horror': 'El Horror Prismático'
  },
  weapons: {
    'oath-sword': { name: 'Voto de Hierro', kind: 'Espada larga' },
    dawnbrand: { name: 'Albaclara', kind: 'Hoja ardiente' },
    'bulwark-mace': { name: 'Bastión de Ormund', kind: 'Maza' },
    'ranger-bow': { name: 'Susurro de Fresno', kind: 'Arco largo' },
    'frost-longbow': { name: 'Colmillo Invernal', kind: 'Arco largo de hielo' },
    'gale-bow': { name: 'Canto del Vendaval', kind: 'Arco de tormenta' },
    'war-axe': { name: 'Cicatriz', kind: 'Hacha de guerra' },
    'quarry-maul': { name: 'Corazón de Cantera', kind: 'Mazo de piedra' },
    'twin-hatchets': { name: 'Hermanas Rojas', kind: 'Hachuelas gemelas' },
    'root-sickle': { name: 'Raíz Antigua', kind: 'Hoz de raíz' },
    'noon-scythe': { name: 'Mediodía', kind: 'Guadaña solar' },
    'thorn-sickle': { name: 'Última Cosecha', kind: 'Hoz de espinas' },
    'trinity-tome': { name: 'Trinidad', kind: 'Tomo de tres sellos' },
    'thunder-codex': { name: 'Voz del Trueno', kind: 'Códice de tormenta' },
    'dusk-grimoire': { name: 'Prisma del Ocaso', kind: 'Libro de cristal' }
  },
  party: {
    battleSkills: 'Habilidades en batalla',
    battleSkillsHint:
      'Cada héroe va a la batalla con el ataque de su arma y hasta {count} habilidades. Cambialas cuando quieras fuera de la pelea.',
    spareSkills: 'Otras habilidades que conoce',
    unequipSkill: 'Quitar {skill}',
    inventory: 'Inventario',
    bestiary: 'Bestiario',
    formationHint: 'Los tres primeros pelean; el resto espera en reserva y entra junto cuando caen los tres.',
    active: 'Activo',
    reserve: 'Reserva',
    moveUp: 'Mover antes en la formación',
    moveDown: 'Mover después en la formación',
    pointsBadge: 'Puntos para gastar',
    swapOnly: 'Las armas se cambian en cualquier punto despejado.',
    attributes: 'Atributos',
    attributePoints: { one: '{count} punto de atributo', other: '{count} puntos de atributo' },
    spendPoint: 'Sumar un punto a {stat}',
    skills: 'Árbol de habilidades',
    skillPoints: { one: '{count} punto de habilidad', other: '{count} puntos de habilidad' },
    treeHint:
      'Aprendé cualquier habilidad conectada a una que ya conozcas: el número es lo que cuesta en puntos. Podés ir primero por la rama que quieras y recorrer las otras después. Cada habilidad sube hasta el nivel {max}.',
    needsLink: 'Primero aprendé una habilidad conectada a esta',
    learn: 'Aprender ({cost} pt)',
    levelUp: 'Subir a nivel {level} ({cost} pts)',
    skillLevel: 'Nivel {level}/{max}',
    skillMax: 'Al máximo',
    rootSkill: 'Habilidad inicial',
    needsPoints: { one: 'Falta {count} punto de habilidad', other: 'Faltan {count} puntos de habilidad' },
    nextLevel: 'Nivel {level}: {effects}',
    notLearned: 'Sin aprender',
    equipped: 'Equipada',
    equipSkill: 'Equipar',
    slotsFull: 'Los {count} espacios están ocupados',
    pickSkill: 'Tocá una habilidad del árbol para verla',
    trade: 'Canjear un punto por {count} Ecos',
    tradeHint: 'El árbol está completo: cada punto de habilidad nuevo puede volverse Ecos de este personaje.',
    tears: { one: '{count} Lágrima del Olvido', other: '{count} Lágrimas del Olvido' },
    spendTear: 'Usar una Lágrima: devuelve todos los puntos de habilidad',
    weapon: 'Arma',
    weapons: 'Armas',
    weaponHeld: 'En mano',
    weaponAttack: '{skill} · {type} · {target}',
    weaponStyle: 'Estilo: {traits}',
    weaponBalanced: 'Estilo: equilibrada',
    wield: 'Empuñar',
    weaponLevel: 'Arma +{level}',
    weaponPower: '+{value} de poder de ataque y especial',
    upgrade: 'Mejorar a +{level}',
    upgradeCost: '{stones} × {stone} · {gold} de oro',
    weaponMax: 'El arma está al máximo.',
    weaponNext: 'En +{level}: {effect}',
    runes: 'Runas',
    emptySlot: 'Espacio libre',
    runeSlots: '{used} de {total} espacios',
    noRunes: 'Todavía no tenés runas: cada santuario guarda una.',
    equip: 'Equipar',
    unequip: 'Quitar',
    wornBy: 'La lleva {name}',
    mastery: 'Dominio {wins}/{needed}',
    mastered: 'Dominada',
    echoes: 'Ecos',
    echoCapacity: 'Ecos {used} de {capacity}',
    echoesHint: 'El eco de una runa dominada da su efecto sin sus cambios de atributos.',
    noEchoes: 'Dominá una runa (4 batallas ganadas con ella puesta) para equipar su eco.',
    echoPool: { one: '{count} Eco para asignar', other: '{count} Ecos para asignar' },
    assign: 'Asignar 1 a {name}',
    assignHint: 'Asignar Ecos a un personaje es para siempre.',
    cost: { one: '{count} Eco', other: '{count} Ecos' },
    have: 'tenés {count}',
    empty: 'Todavía no hay nada.',
    owned: '× {count}',
    bestiaryHint: 'Derrotá más de cada especie para saber más sobre ella.',
    kills: { one: '{count} derrotado', other: '{count} derrotados' },
    nextUnlock: 'Más a las {count}',
    weakTo: 'Débil a {types}',
    resists: 'Resiste {types}',
    immuneTo: 'Inmune a {types}',
    absorbs: 'Absorbe {types}',
    noWeakness: 'Sin debilidades',
    archetype: 'Tipo: {archetype}',
    statsLine: 'Vida {health} · Ataque {attack} · Defensa {defense} · Velocidad {speed} (nivel {level})',
    skillsLine: 'Habilidades: {skills}',
    dropsLine: 'Deja: {items}',
    status: 'Estado',
    health: 'Vida',
    focus: 'Concentración',
    experience: 'Experiencia',
    tabs: {
      status: 'Estado',
      attributes: 'Atributos',
      weapons: 'Armas',
      skills: 'Habilidades',
      runes: 'Runas'
    },
    openHero: 'Ver a {name}',
    previousHero: 'Héroe anterior',
    nextHero: 'Héroe siguiente',
    formationPlace: 'Puesto {place} de {total}',
    echoesBadge: 'Hay Ecos para asignar',
    upgradeCampOnly: 'Las armas se mejoran en un campamento.',
    runesCampOnly: 'Las runas se equipan y se quitan en un campamento.',
    echoesCampOnly: 'Los ecos se equipan y se quitan en un campamento.'
  },
  attributes: {
    maxHealth: 'Vida',
    maxFocus: 'Concentración',
    defense: 'Defensa',
    speed: 'Velocidad',
    attack: 'Ataque',
    special: 'Ataque especial',
    critChance: 'Prob. de crítico',
    critDamage: 'Daño crítico'
  },
  archetypes: {
    brute: 'Bruto',
    agile: 'Ágil',
    tank: 'Tanque',
    caster: 'Lanzador',
    healer: 'Sanador'
  },
  damageTypes: {
    slash: 'Corte',
    pierce: 'Perforante',
    blunt: 'Contundente',
    fire: 'Fuego',
    ice: 'Hielo',
    lightning: 'Rayo',
    earth: 'Tierra',
    light: 'Luz',
    darkness: 'Oscuridad'
  },
  targets: {
    enemy: 'un enemigo',
    allEnemies: 'todos los enemigos',
    ally: 'un aliado',
    allAllies: 'todos los aliados',
    self: 'sí mismo'
  },
  bonuses: {
    stat: '{value} {stat}',
    lifesteal: 'Se cura el {value} del daño que hace',
    focusRegen: '+{value} de concentración por ataque normal',
    regen: 'Recupera el {value} de la vida por turno',
    initiative: 'Empieza las batallas un {value}% adelantado en los turnos',
    guard: 'Recibe un {value} menos de daño',
    damage: '{value} de daño de {type}',
    weakness: '{value} de daño sobre debilidades',
    statusChance: '{value} de probabilidad de sus estados',
    onHit: 'Sus ataques pueden causar {status} ({value})',
    power: '{skill}: +{value} de poder',
    skillCost: '{skill}: {value} menos de concentración',
    skillStatus: '{skill}: +{value} de probabilidad de sus estados',
    skillTurns: '{skill}: +{value} turno de sus estados',
    skillInfo: '{cost} de conc. · {target} · {type}'
  },
  skillEffects: {
    damage: 'Daño de {type} ×{power} a {target}',
    heal: 'Cura ×{power} a {target}',
    buff: 'Sobre {target}',
    revive: 'Revive a un aliado caído',
    cure: 'Quita los estados dañinos',
    status: '{status}: {chance} · {turns} turnos',
    statusSelf: '{status} sobre sí mismo · {turns} turnos',
    crit: '+{value} de prob. de crítico',
    fury: 'Gasta la furia para más poder',
    charges: 'Gasta las cargas elementales para más poder',
    stanceNeeds: 'Solo en postura {stances}',
    stanceTo: 'Pasa a postura {stance}',
    stanceDrop: 'Lo deja sin postura',
    power: '+{value} de poder',
    chance: '+{value} de prob. de estados',
    cost: '−{value} de concentración',
    turns: '+{value} turno de estados',
    shields: { one: 'Da {count} escudo: anula un golpe completo', other: 'Da {count} escudos: cada uno anula un golpe' }
  },
  runes: {
    'first-cut': { name: 'Runa del Primer Tajo', text: 'El primer golpe que da en cada batalla hace +50% de daño.' },
    breath: { name: 'Runa del Aliento', text: 'Empieza cada batalla con +30% de concentración.' },
    sprout: { name: 'Runa del Brote', text: 'Durante sus 3 primeros turnos recupera 5% de vida al empezar el turno.' },
    'light-step': { name: 'Runa del Paso Ligero', text: 'Empieza la batalla con velocidad aumentada por 3 turnos.' },
    carapace: { name: 'Runa de la Coraza', text: 'Empieza la batalla con defensa aumentada por 3 turnos.' },
    impetus: { name: 'Runa del Ímpetu', text: 'Empieza la batalla con ataque aumentado por 3 turnos.' },
    wisdom: { name: 'Runa de la Sabiduría', text: 'El grupo gana 25% más de experiencia en cada batalla.' },
    'live-ember': { name: 'Runa de la Brasa Viva', text: '+25% de daño a enemigos quemados.' },
    finisher: { name: 'Runa del Remate', text: 'Al derrotar a un enemigo recupera 15% de vida.' },
    'true-pulse': {
      name: 'Runa del Pulso Certero',
      text: 'Cada crítico le devuelve 10% de concentración (una vez por turno).'
    },
    fang: { name: 'Runa del Colmillo', text: 'El ataque con arma tiene 20% de envenenar por 3 turnos.' },
    pause: { name: 'Runa de la Pausa', text: 'Al usar un objeto recupera 15% de concentración.' },
    'whole-body': { name: 'Runa del Cuerpo Entero', text: '+20% de daño mientras tiene la vida llena.' },
    'double-edge': { name: 'Runa del Doble Filo', text: 'El ataque con arma golpea dos veces, cada golpe al 60%.' },
    'stubborn-ember': { name: 'Runa del Ascua Terca', text: 'Las quemaduras que deja duran 2 turnos más.' },
    contagion: {
      name: 'Runa del Contagio',
      text: 'Dejarle un estado a un enemigo le devuelve 10% de concentración (una vez por turno).'
    },
    tribute: { name: 'Runa del Tributo', text: 'El grupo gana 30% más de oro en cada victoria.' },
    'warm-up': { name: 'Runa del Calentamiento', text: '+5% de daño por cada turno propio, hasta +25%.' },
    'untouched-skin': { name: 'Runa de la Piel Intacta', text: '+30% de daño hasta que recibe el primer golpe.' },
    'last-breath': { name: 'Runa del Último Aliento', text: '+50% de daño con menos del 15% de vida.' },
    'right-moment': {
      name: 'Runa del Momento Justo',
      text: '+30% de probabilidad de crítico con menos del 30% de vida.'
    },
    rescue: {
      name: 'Runa del Socorro',
      text: 'La primera vez que baja del 50% de vida gana defensa aumentada por 3 turnos.'
    },
    'clean-blow': {
      name: 'Runa del Golpe Seco',
      text: 'Sus golpes a enemigos aturdidos o congelados son siempre críticos.'
    },
    icebreaker: { name: 'Runa del Rompehielo', text: '+40% de daño a enemigos congelados.' },
    'open-wound': { name: 'Runa de la Herida Abierta', text: 'Sus críticos dejan sangrado por 3 turnos.' },
    'full-healing': { name: 'Runa de la Sanación Plena', text: 'Las curaciones que recibe curan el doble.' },
    'generous-hand': {
      name: 'Runa de la Mano Generosa',
      text: 'Al curar a un aliado, también se cura el 30% de esa curación.'
    },
    clover: {
      name: 'Runa del Trébol',
      text: 'Suerte: los enemigos dejan objetos, piedras y pociones un 50% más seguido.'
    },
    cheer: { name: 'Runa del Ánimo', text: 'Al curar a alguien le da ataque aumentado por 2 turnos.' },
    harvest: { name: 'Runa de la Cosecha', text: 'Al derrotar a un enemigo recupera 30% de concentración.' },
    'hunter-eye': {
      name: 'Runa del Ojo del Cazador',
      text: '+25% de probabilidad de crítico contra enemigos con algún estado negativo.'
    },
    'burning-iron': {
      name: 'Runa del Hierro Ardiente',
      text: 'El ataque con arma hace daño de fuego en vez de físico.'
    },
    'frozen-iron': { name: 'Runa del Hierro Gélido', text: 'El ataque con arma hace daño de hielo en vez de físico.' },
    'thunder-iron': {
      name: 'Runa del Hierro Tronante',
      text: 'El ataque con arma hace daño de rayo en vez de físico.'
    },
    reprisal: { name: 'Runa del Escarmiento', text: 'Al recibir un golpe tiene 25% de contraatacar con el arma.' },
    'clean-blood': { name: 'Runa de la Sangre Limpia', text: 'No puede ser envenenado, quemado ni sangrar.' },
    vigil: { name: 'Runa de la Vigilia', text: 'Cuando cae un aliado, actúa de inmediato.' },
    temper: { name: 'Runa del Temple', text: 'No puede ser congelado ni aturdido.' },
    'clear-sight': {
      name: 'Runa de la Mirada Clara',
      text: 'No puede quedar ciego ni recibir bajas de ataque, defensa o velocidad.'
    },
    glass: { name: 'Runa del Cristal', text: '+35% de daño hecho y +25% de daño recibido.' },
    pride: { name: 'Runa del Orgullo', text: 'Recibe 40% menos de daño, pero no puede ser curado.' },
    recklessness: { name: 'Runa de la Temeridad', text: '+35% de daño, pero no puede ser curado.' },
    coin: { name: 'Runa de la Moneda', text: 'Cada golpe hace la mitad o el doble de daño, mitad y mitad.' },
    endurance: { name: 'Runa del Aguante', text: 'Una vez por batalla sobrevive a un golpe mortal con 1 de vida.' },
    'second-flame': { name: 'Runa de la Segunda Llama', text: 'Una vez por batalla, al caer revive con 50% de vida.' },
    martyr: { name: 'Runa del Mártir', text: 'Al caer, cura 40% de vida a sus aliados.' },
    'posthumous-wrath': {
      name: 'Runa de la Ira Póstuma',
      text: 'Al caer, sus aliados ganan ataque aumentado por 3 turnos.'
    },
    'final-blast': {
      name: 'Runa del Estallido Final',
      text: 'Al caer, daña a todos los enemigos con el doble de su ataque.'
    },
    'lone-wolf': {
      name: 'Runa del Lobo Solitario',
      text: 'Si es el único héroe en pie: +50% de daño y velocidad aumentada.'
    },
    company: { name: 'Runa de la Compañía', text: '+12% de daño mientras los tres héroes del frente siguen en pie.' },
    frenzy: {
      name: 'Runa del Frenesí',
      text: 'Cada especial seguido, sin un ataque con arma en el medio, hace +15% más, hasta +60%.'
    },
    thrift: { name: 'Runa de la Economía', text: 'Los especiales cuestan 15% menos de concentración.' },
    spring: { name: 'Runa del Manantial', text: 'Al empezar cada turno recupera 8% de concentración.' },
    'patient-apprentice': {
      name: 'Runa del Aprendiz Paciente',
      text: '+5% de daño por cada turno propio sin recibir daño, hasta +25%. Recibir daño lo reinicia.'
    },
    dawn: { name: 'Runa del Albor', text: 'Siempre actúa primero al empezar la batalla.' },
    lightning: { name: 'Runa del Relámpago', text: 'Al derrotar a un enemigo, su próximo turno llega antes.' },
    'third-blow': { name: 'Runa del Tercer Golpe', text: 'Cada tercer especial hace el doble de daño.' },
    counterpoint: {
      name: 'Runa del Contrapunto',
      text: 'Después de un crítico, el siguiente golpe que no sea crítico hace el doble.'
    },
    fever: { name: 'Runa de la Fiebre', text: 'El veneno, la quemadura y el sangrado que deja hacen 50% más de daño.' },
    plague: { name: 'Runa de la Plaga', text: 'Al derrotar a un enemigo envenenado, el veneno pasa a otro enemigo.' },
    barrier: { name: 'Runa de la Barrera', text: 'Empieza la batalla con 1 escudo más, que anula un golpe completo.' },
    aegis: { name: 'Runa de la Égida', text: 'Al curar a alguien sin escudos le da 1, que anula un golpe completo.' },
    'blood-echo': {
      name: 'Runa del Eco de Sangre',
      text: 'Se cura el 12% de todo el daño que hace, especiales incluidos.'
    },
    shelter: { name: 'Runa del Amparo', text: 'Al caer, da 1 escudo a cada aliado que no tenga ninguno.' },
    breach: { name: 'Runa de la Brecha', text: 'Golpear una debilidad le baja la defensa al enemigo por 2 turnos.' },
    respite: {
      name: 'Runa del Respiro',
      text: 'Al ganar la batalla, los héroes en pie recuperan el 25% de su vida.'
    },
    persistence: {
      name: 'Runa del Ahínco',
      text: 'Los aumentos de ataque, defensa y velocidad que recibe duran 2 turnos más.'
    },
    'full-cup': {
      name: 'Runa del Cáliz Lleno',
      text: 'Con la concentración llena, sus especiales hacen +30% de daño.'
    },
    twin: { name: 'Runa del Desdoble', text: 'Siempre actúa dos veces seguidas, pero hace 40% menos de daño.' },
    'abyss-edge': { name: 'Runa del Filo del Abismo', text: 'Su vida máxima baja un 70%, pero hace +80% de daño.' },
    'perfect-instant': {
      name: 'Runa del Instante Perfecto',
      text: 'Si no recibió daño desde su turno anterior, al empezar el turno recupera toda la vida.'
    },
    void: {
      name: 'Runa del Vacío',
      text: 'Sus golpes ignoran las resistencias: lo resistido pega normal y lo inmune pega a la mitad.'
    },
    crucible: { name: 'Runa del Crisol', text: '+15% de daño por cada estado, bueno o malo, que tenga encima.' },
    eclipse: {
      name: 'Runa del Eclipse',
      text: 'Al derrotar a un enemigo vuelve a actuar en el acto (una vez por turno).'
    },
    legacy: { name: 'Runa de la Herencia', text: 'Al caer, sus aliados recuperan toda la vida y la concentración.' },
    judgment: { name: 'Runa del Juicio', text: 'Cada quinto golpe hace +300% de daño.' }
  },
  items: {
    'health-potion': { name: 'Poción de vida', text: 'Cura el 35% de la vida de un aliado.' },
    'focus-potion': { name: 'Poción de concentración', text: 'Devuelve la mitad de la concentración de un aliado.' },
    antidote: {
      name: 'Antídoto',
      text: 'Cura veneno, quemaduras, sangrado, ceguera, congelación, aturdimiento y debilitamientos.'
    },
    'fire-bomb': { name: 'Bomba de fuego', text: 'Daño de fuego a todos los enemigos.' },
    'greater-health-potion': { name: 'Poción de vida mayor', text: 'Cura el 70% de la vida de un aliado.' },
    'greater-focus-potion': {
      name: 'Poción de concentración mayor',
      text: 'Devuelve toda la concentración de un aliado.'
    },
    'revive-potion': { name: 'Poción de revivir', text: 'Levanta a un aliado caído con el 40% de su vida.' },
    'frost-bomb': { name: 'Bomba de escarcha', text: 'Daño de hielo a todos los enemigos, que puede congelarlos.' },
    elixir: { name: 'Elixir', text: 'Cura a todo el grupo, devuelve su concentración y quita sus estados.' },
    'crusty-bread': { name: 'Pan crocante', text: 'Cura el 20% de la vida de un aliado.' },
    'red-apple': {
      name: 'Manzana roja',
      text: 'Cura el 12% de la vida y devuelve el 15% de la concentración de un aliado.'
    },
    'wild-berries': {
      name: 'Bayas silvestres',
      text: 'Cura el 8% de la vida de un aliado y lo regenera durante 3 turnos.'
    },
    'honey-cake': { name: 'Torta de miel', text: 'Devuelve el 35% de la concentración de un aliado.' },
    'mushroom-skewer': {
      name: 'Brocheta de hongos',
      text: 'Cura el 15% de la vida de un aliado y lo regenera durante 3 turnos.'
    },
    'roast-meat': { name: 'Carne asada', text: 'Cura el 40% de la vida de un aliado.' },
    'fish-stew': {
      name: 'Guiso de pescado',
      text: 'Cura el 30% de la vida y devuelve el 20% de la concentración de un aliado.'
    },
    'spicy-sausage': {
      name: 'Chorizo picante',
      text: 'Cura el 20% de la vida de un aliado y le sube el ataque durante 2 turnos.'
    },
    'traveler-feast': {
      name: 'Banquete del viajero',
      text: 'Cura el 25% de la vida de todo el grupo y lo regenera durante 3 turnos.'
    },
    'golden-pear': {
      name: 'Pera dorada',
      text: 'Cura la mitad de la vida y devuelve la mitad de la concentración de un aliado.'
    },
    'might-tonic': { name: 'Tónico de fuerza', text: 'Sube el ataque de un aliado durante 3 turnos.' },
    'iron-tonic': { name: 'Tónico de hierro', text: 'Sube la defensa de un aliado durante 3 turnos.' },
    'swift-tonic': { name: 'Tónico de presteza', text: 'Sube la velocidad de un aliado durante 3 turnos.' },
    'keen-tonic': {
      name: 'Tónico de precisión',
      text: 'Sube un 20% la probabilidad de crítico de un aliado durante 3 turnos.'
    },
    'troll-blood': { name: 'Sangre de trol', text: 'Regenera a un aliado durante 4 turnos.' },
    'giant-draught': {
      name: 'Brebaje del gigante',
      text: 'Sube el ataque y la defensa de un aliado durante 3 turnos.'
    },
    'war-elixir': {
      name: 'Elixir de guerra',
      text: 'Sube el ataque y la velocidad de todo el grupo durante 2 turnos.'
    },
    'throwing-knife': { name: 'Cuchillo arrojadizo', text: 'Daño cortante a un enemigo.' },
    'serrated-knife': { name: 'Cuchillo dentado', text: 'Daño cortante a un enemigo, que puede hacerlo sangrar.' },
    'poison-dart': { name: 'Dardo envenenado', text: 'Poco daño perforante a un enemigo, que suele envenenarlo.' },
    'stun-dart': { name: 'Dardo somnífero', text: 'Poco daño perforante a un enemigo, que puede aturdirlo.' },
    shuriken: { name: 'Estrellas arrojadizas', text: 'Tres golpes cortantes a un enemigo.' },
    javelin: { name: 'Jabalina', text: 'Mucho daño perforante a un enemigo.' },
    'throwing-axe': { name: 'Hacha arrojadiza', text: 'Daño cortante a un enemigo, que puede bajarle la defensa.' },
    'pepper-pouch': { name: 'Saquito de pimienta', text: 'No hace daño, pero suele dejar ciego a un enemigo.' },
    'flame-dagger': { name: 'Daga ígnea', text: 'Daño de fuego a un enemigo, que puede quemarlo.' },
    'frost-dagger': { name: 'Daga de escarcha', text: 'Daño de hielo a un enemigo, que puede congelarlo.' },
    'storm-kunai': { name: 'Kunai de tormenta', text: 'Daño de rayo a un enemigo, que puede aturdirlo.' },
    'holy-water': { name: 'Agua bendita', text: 'Daño de luz a un enemigo, que puede dejarlo ciego.' },
    'shadow-needle': { name: 'Aguja de sombra', text: 'Daño de oscuridad a un enemigo, que puede bajarle el ataque.' },
    'thunder-bomb': { name: 'Bomba de trueno', text: 'Daño de rayo a todos los enemigos, que puede aturdirlos.' },
    'acid-flask': {
      name: 'Frasco de ácido',
      text: 'Poco daño de tierra a todos los enemigos, que suele bajarles la defensa.'
    },
    'smoke-bomb': { name: 'Bomba de humo', text: 'No hace daño, pero puede dejar ciegos a todos los enemigos.' },
    'spore-bomb': {
      name: 'Bomba de esporas',
      text: 'Poco daño de tierra a todos los enemigos, que suele envenenarlos.'
    },
    'shrapnel-bomb': {
      name: 'Bomba de metralla',
      text: 'Daño perforante a todos los enemigos, que puede hacerlos sangrar.'
    },
    'radiant-orb': { name: 'Orbe radiante', text: 'Daño de luz a todos los enemigos.' },
    'void-bomb': {
      name: 'Bomba del vacío',
      text: 'Daño de oscuridad a todos los enemigos, que puede bajarles el ataque.'
    },
    'fire-oil': {
      name: 'Aceite ígneo',
      text: 'Durante 4 turnos los ataques con el arma de un aliado son de fuego y pueden quemar.'
    },
    'frost-oil': {
      name: 'Aceite de escarcha',
      text: 'Durante 4 turnos los ataques con el arma de un aliado son de hielo y pueden congelar.'
    },
    'storm-oil': {
      name: 'Aceite de tormenta',
      text: 'Durante 4 turnos los ataques con el arma de un aliado son de rayo y pueden aturdir.'
    },
    'earth-oil': {
      name: 'Aceite de tierra',
      text: 'Durante 4 turnos los ataques con el arma de un aliado son de tierra y pueden bajar la defensa.'
    },
    'holy-oil': {
      name: 'Aceite sagrado',
      text: 'Durante 4 turnos los ataques con el arma de un aliado son de luz y pueden cegar.'
    },
    'shadow-oil': {
      name: 'Aceite de sombra',
      text: 'Durante 4 turnos los ataques con el arma de un aliado son de oscuridad y pueden bajar el ataque.'
    },
    'venom-oil': {
      name: 'Aceite de veneno',
      text: 'Durante 4 turnos los ataques con el arma de un aliado pueden envenenar.'
    },
    'ward-charm': { name: 'Amuleto protector', text: 'Durante 3 turnos ningún estado dañino alcanza a un aliado.' },
    'purifying-incense': {
      name: 'Incienso purificador',
      text: 'Quita los estados dañinos de todo el grupo y lo protege de ellos durante 2 turnos.'
    },
    'saint-amulet': {
      name: 'Amuleto de la santa',
      text: 'Quita los estados dañinos de un aliado y lo protege de ellos durante 5 turnos.'
    },
    'guard-seal': { name: 'Sello guardián', text: 'Da 1 escudo a un aliado: anula por completo el próximo golpe.' },
    'bulwark-crystal': {
      name: 'Cristal de baluarte',
      text: 'Da 2 escudos a un aliado: cada uno anula un golpe completo.'
    },
    'aegis-relic': {
      name: 'Reliquia de la égida',
      text: 'Da 3 escudos a un aliado: cada uno anula un golpe completo.'
    },
    'shield-scroll': {
      name: 'Pergamino de escudos',
      text: 'Da 1 escudo a cada aliado: anula por completo su próximo golpe.'
    },
    'sling-stone': { name: 'Piedra de honda', text: 'Daño contundente a un enemigo, que puede aturdirlo.' },
    'rough-stone': { name: 'Piedra tosca', text: 'Mejora un arma de +1 a +5.' },
    'tempered-stone': { name: 'Piedra templada', text: 'Mejora un arma de +6 a +10.' },
    'arcane-stone': { name: 'Piedra arcana', text: 'Mejora un arma de +11 a +15.' },
    'abyssal-stone': { name: 'Piedra abisal', text: 'Mejora un arma de +16 a +20.' }
  },
  inventory: {
    tabs: {
      all: 'Todo',
      potions: 'Pociones',
      food: 'Comida',
      throwables: 'Arrojables',
      oils: 'Aceites',
      charms: 'Amuletos',
      stones: 'Piedras',
      runes: 'Runas',
      special: 'Especiales'
    },
    empty: {
      all: 'El inventario está vacío.',
      potions: 'No llevás pociones ni tónicos.',
      food: 'No llevás comida.',
      throwables: 'No llevás armas arrojadizas ni bombas.',
      oils: 'No llevás aceites para el arma.',
      charms: 'No llevás amuletos ni sellos de escudo.',
      stones: 'No llevás piedras de herrería.',
      runes: 'Todavía no tenés runas: cada santuario guarda una.',
      special: 'No tenés objetos especiales.'
    },
    use: 'Usar',
    battleOnly: 'Se usa durante una batalla: cada héroe puede usar hasta 3 objetos por turno.',
    stoneUse: 'Se usa para mejorar armas en un campamento, desde la página de cada héroe.',
    runeTier: 'Runa {tier}',
    runeUse: 'Se equipa desde la página de un héroe, en un campamento.',
    tear: {
      name: 'Lágrima del Olvido',
      text: 'Devuelve todos los puntos de habilidad de un héroe, para aprender de nuevo su árbol.',
      chooseHero: '¿Quién olvida?',
      nobody: 'Ningún héroe aprendió habilidades de su árbol todavía.'
    }
  },
  bestiary: {
    discovered: 'Descubiertos {count} de {total}',
    empty: 'Todavía no derrotaste a ningún enemigo.',
    nothingYet: 'Derrotá más de esta especie para conocer sus debilidades.'
  },
  shop: {
    gold: '{gold} de oro',
    buy: 'Comprar · {price}',
    full: 'Ya llevás el máximo',
    echo: 'Un Eco',
    echoText: 'Va al fondo común, para asignarlo a un personaje para siempre.',
    echoesLeft: { one: 'Queda {count} en este ciclo', other: 'Quedan {count} en este ciclo' },
    soldOut: 'No hay más Ecos hasta el próximo ciclo.'
  },
  characters: {
    kael: { name: 'Kael' },
    sera: { name: 'Sera' },
    brann: { name: 'Brann' },
    oren: { name: 'Oren' },
    ysolde: { name: 'Ysolde' }
  },
  errors: {
    internal: 'Error interno',
    notAuthenticated: 'Usuario no autenticado',
    unauthorized: 'No autorizado',
    playerNameRequired: 'Elegí un nombre de jugador',
    playerNameTooLong: 'El nombre de jugador puede tener hasta 40 caracteres',
    lastNameTooLong: 'El apellido puede tener hasta 40 caracteres',
    nicknameTooLong: 'El apodo puede tener hasta 40 caracteres',
    invalidLocale: 'Idioma inválido',
    saveNotFound: 'No tenés una partida guardada',
    invalidSave: 'La partida guardada no es válida',
    saveOutdated: 'Tu partida avanzó en otro dispositivo: volvé a cargarla',
    emailRequired: 'Ingresá tu email',
    invalidEmail: 'El email no es válido',
    passwordTooShort: 'La contraseña debe tener al menos {min} caracteres',
    emailAlreadyRegistered: 'El email ya está registrado',
    fillAllFields: 'Completá todos los campos',
    linkInvalidOrUsed: 'El enlace no es válido o ya fue usado',
    linkExpired: 'El enlace expiró. Pedí uno nuevo'
  }
}

export type Messages = typeof es
