import { Application, Container, Graphics, Sprite, Text, Texture } from 'pixi.js'
import { HERO_LOADOUTS, heroRig, Rig, RIGS } from '@/app/(protected)/(art)/data/rigs'
import { SHADOW_ALPHA, shadowOf } from '@/app/(protected)/(art)/data/shadows'
import { ArtManifest } from '@/app/(protected)/(art)/models/ArtManifest'
import { figureArtId, loadArtManifest, loadTextures } from '@/app/(protected)/(art)/utils/art'
import { RigFigure, rigPartIds } from '@/app/(protected)/(art)/utils/rig'
import { playSfx } from '@/app/(protected)/(art)/utils/sound'
import { ArrowKind, arrowKindOf, drawArrow, drawImpact, drawTrail } from '@/app/(protected)/(battle)/utils/arrows'
import { ActorStyle, AttackEffect, attackEffectOf, LOOK_COLORS } from '@/app/(protected)/(battle)/utils/attackEffects'
import { AttackVisuals, EffectTarget, HitOutcome } from '@/app/(protected)/(battle)/utils/attackVisuals'
import { BattleScenery, FLOOR_LINE, MAX_PAN, SceneryProp } from '@/app/(protected)/(battle)/utils/battleScenery'
import { soundOf } from '@/app/(protected)/(battle)/utils/battleSounds'
import { initialQuality, Particles, prefersReducedMotion } from '@/app/(protected)/(battle)/utils/particles'
import { STATUS_COLORS, StatusAura } from '@/app/(protected)/(battle)/utils/statusVisuals'
import { getCharacterDefinition } from '@/app/(protected)/(engine)/data/characters'
import { getSpecies } from '@/app/(protected)/(engine)/data/enemies'
import { getSkill } from '@/app/(protected)/(engine)/data/skills'
import { getWeapon } from '@/app/(protected)/(engine)/data/weapons'
import { Archetype } from '@/app/(protected)/(engine)/models/Archetype'
import { BattleEvent } from '@/app/(protected)/(engine)/models/BattleEvent'
import { BattleState } from '@/app/(protected)/(engine)/models/BattleState'
import { CharacterId } from '@/app/(protected)/(engine)/models/CharacterId'
import { Combatant } from '@/app/(protected)/(engine)/models/Combatant'
import { DamageType } from '@/app/(protected)/(engine)/models/DamageType'
import { Perk } from '@/app/(protected)/(engine)/models/Perk'
import { Stance } from '@/app/(protected)/(engine)/models/Stance'
import { StatusType } from '@/app/(protected)/(engine)/models/StatusType'
import { TargetType } from '@/app/(protected)/(engine)/models/TargetType'
import { paintSceneryTextures, SceneryTextures } from '@/app/(protected)/(world)/utils/sceneryTextures'

/** Texts the scene shows over the fighters (already translated). */
export interface BattleLabels {
  skill: (skillId: string) => string
  item: (itemId: string) => string
  status: (status: StatusType) => string
  stance: (stance: Stance) => string
  weak: string
  resist: string
  immune: string
  miss: string
  transform: string
  /** The name of the rune whose effect acted. */
  perk: (perk: Perk) => string
  /** A shield stopped a hit / shields were gained. */
  shieldBlock: string
  shieldGain: (count: number) => string
}

/** One fighter drawn on the stage. */
interface Figure {
  id: string
  root: Container
  body: Container
  healthBar: Graphics
  barsText: Text | null
  /** The shields it has: a shield with their number, beside its health bar (hidden with none). */
  shieldBadge: Container
  shieldText: Text
  shields: number
  statusText: Text
  /** What its statuses look like on it (poison bubbles, ice, stars...), see statusVisuals.ts. */
  aura: StatusAura
  side: Combatant['side']
  /** The puppet, when the figure is put together from a parts sheet. */
  rig: RigFigure | null
  /** How it fights: walking up to its target, shooting arrows from its spot (see shoot) or casting spells. */
  style: ActorStyle
  /** The elemental charges that go round it (Ysolde), one orb each. */
  orbs: Container | null
  size: number
  /** Its shadow (data/shadows), in pixels of a fighter of size 1: the rings at its feet follow it. */
  shadow: ReturnType<typeof shadowOf>
  health: number
  maxHealth: number
  bars: number
  home: { x: number; y: number }
}

const DAMAGE_COLORS: Partial<Record<DamageType, number>> = {
  [DamageType.FIRE]: 0xff8a00,
  [DamageType.ICE]: 0x7dd3fc,
  [DamageType.LIGHTNING]: 0xfde047,
  [DamageType.EARTH]: 0xd6a35c,
  [DamageType.LIGHT]: 0xfff7c2,
  [DamageType.DARKNESS]: 0xc084fc
}
const FONT = "'Lilita One', Nunito, sans-serif"
/** Height of a fighter of size 1, in stage pixels at scale 1. */
export const FIGURE_HEIGHT = 120
const OUTLINE = 0x0a0710

/** The puppet of a fighter: a hero holds its weapon (the one it starts with while that image is missing). */
function rigOf(combatant: Combatant, artId: string, parts: ArtManifest['parts']): Rig | null {
  if (combatant.side === 'hero' && combatant.weaponId) {
    const id = combatant.characterId!
    const rig = heroRig(id, { ...HERO_LOADOUTS[id], weapon: getWeapon(combatant.weaponId).art })

    if (parts[rig.images.weapon ?? '']) {
      return rig
    }
  }

  return RIGS[artId] ?? null
}

/** The shield of the badge of shields (its number goes on top), centered on 0. */
function drawShieldIcon(): Graphics {
  const g = new Graphics()

  g.poly([-11, -12, 11, -12, 11, -1, 0, 13, -11, -1])
    .fill({ color: 0x2f7fe0 })
    .stroke({ width: 3, color: OUTLINE, join: 'round' })
  g.poly([-8, -9, 8, -9, 8, -2, 0, 9, -8, -2]).stroke({ width: 1.5, color: 0x9fd8ff, alpha: 0.9 })
  g.poly([-7, -8, -1, -8, -7, -1]).fill({ color: 0xffffff, alpha: 0.35 })

  return g
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

/**
 * The side-view battle scene (Hero Wars style) drawn with PixiJS: heroes on
 * the left, monsters on the right, provisional figures made of shapes,
 * floating numbers, flashes and camera shake, over a layered scenery that
 * gives it depth (see BattleScenery). A slow camera sways and leans towards
 * each action. It only shows what the engine says (see `play`); the choices
 * are made in the React interface.
 */
export class BattleRenderer {
  private readonly stage = new Container()
  /** Everything the camera sees (it zooms around the ground line; the stage itself shakes). */
  private readonly world = new Container()
  private readonly fighters = new Container()
  private readonly effects = new Container()
  /** The effects that go on the ground, under the fighters (rings, cracks, spikes). */
  private readonly groundEffects = new Container()
  /** A flash over the whole screen (lightning, a meteor); it does not move with the camera. */
  private readonly flashLayer = new Graphics()
  private readonly particles: Particles
  private readonly visuals: AttackVisuals
  private readonly reducedMotion = prefersReducedMotion()
  /** Average time of a frame (ms): when it is slow the effects drop to their light quality. */
  private frameTime = 16
  private readonly figures = new Map<string, Figure>()
  private readonly marker = new Graphics()
  private markedId: string | null = null
  /** The fighters the player can pick now (an arrow bobs over each one). */
  private targetIds: string[] = []
  /** Room the screen covers at the top and at the bottom (its HUD): the fighters stand in what is left. */
  private insets = { top: 0, bottom: 0 }
  private lastBattle: BattleState | null = null
  private elapsed = 0
  /** The camera: how far it panned right (pixels) and its zoom, easing towards their targets. */
  private readonly camera = { x: 0, zoom: 1, targetX: 0, targetZoom: 1 }
  /** Follows the size of the element (it can change without the window doing so, e.g. panels below it). */
  private resizeObserver: ResizeObserver | null = null
  /** Animation speed (×1 or ×2). */
  speed = 1

  private constructor(
    private readonly app: Application,
    private readonly labels: BattleLabels,
    private readonly onTap: (combatantId: string) => void,
    /** The final art that exists for this battle (figures by art id, and the background). */
    private readonly art: Map<string, Texture>,
    private readonly parts: ArtManifest['parts'],
    private readonly scenery: BattleScenery
  ) {
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    const host = this

    this.particles = new Particles(app.renderer, initialQuality())
    this.visuals = new AttackVisuals(
      {
        ms: (value) => value / this.speed,
        tween: (duration, update) => this.tween(duration, update),
        wait: (duration) => wait(duration),
        get scale() {
          return host.scale
        },
        flash: (color, alpha, duration) => this.flash(color, alpha, duration),
        shake: (duration, strength) => void this.shake(duration, strength)
      },
      this.groundEffects,
      this.effects,
      this.particles
    )
    this.world.addChild(
      scenery.back,
      this.marker,
      this.groundEffects,
      this.fighters,
      this.effects,
      this.particles.view,
      scenery.front
    )
    this.stage.addChild(this.world, this.flashLayer)
    app.stage.addChild(this.stage)
    app.ticker.add((ticker) => this.animate(ticker.deltaMS))
  }

  static async create(
    element: HTMLElement,
    battle: BattleState,
    labels: BattleLabels,
    onTap: (combatantId: string) => void,
    /** A painted background for special places (null: the scenery builds the biome's landscape). */
    background: string | null,
    /** Each point of the map has its own scenery, made from this (its id). */
    sceneSeed: string
  ): Promise<BattleRenderer> {
    const app = new Application()
    const { images, parts, props, decorations, battle: landscapes } = await loadArtManifest()
    const backgroundId = background && images[background] ? background : null
    const landscape = landscapes[battle.biome] ?? { bands: [], landmarks: [] }
    const heroes = battle.combatants.filter((combatant) => combatant.side === 'hero')
    const figureIds = [
      ...heroes.map((hero) => figureArtId('hero', hero.characterId!, false)),
      ...battle.phases
        .flat()
        .map((spawn) => figureArtId('enemy', spawn.speciesId, getSpecies(spawn.speciesId).rarity === 'boss'))
    ]
    const heroRigs = heroes.map((hero) => rigOf(hero, figureArtId('hero', hero.characterId!, false), parts))
    // The biome's battle props; until they exist, its map decorations that stand upright.
    const propIds = props[battle.biome]?.length
      ? props[battle.biome]
      : (decorations[battle.biome] ?? []).filter((id) => images[id] && images[id].width < images[id].height * 1.45)
    const art = await loadTextures([
      ...(backgroundId ? [backgroundId] : []),
      ...landscape.bands,
      ...landscape.landmarks,
      ...(landscape.floor ? [landscape.floor] : []),
      ...propIds,
      ...figureIds,
      ...figureIds.flatMap((id) => (RIGS[id] ? rigPartIds(RIGS[id], parts) : [])),
      ...heroRigs.flatMap((rig) => (rig ? rigPartIds(rig, parts) : []))
    ])

    await app.init({
      resizeTo: element,
      background: '#07040d',
      antialias: true,
      autoDensity: true,
      resolution: Math.min(window.devicePixelRatio || 1, 2)
    })
    element.appendChild(app.canvas)

    const tallest = Math.max(1, ...propIds.map((id) => images[id].height))
    const fromSheet = !!props[battle.biome]?.length
    const provisional = provisionalScenery()[battle.biome]
    const sceneryProps: SceneryProp[] = propIds
      .filter((id) => art.has(id))
      .map((id) => {
        // Sheet props keep their sizes; map decorations come all the same size, so only tall or low.
        const height = fromSheet ? images[id].height / tallest : images[id].height > images[id].width * 1.1 ? 1 : 0.4

        return { texture: art.get(id)!, height, framing: fromSheet && height >= 0.6 }
      })

    // Until a biome has art of its own, the provisional drawings of its map scenery.
    if (sceneryProps.length === 0) {
      const tallestDrawing = Math.max(1, ...provisional.tall.map((texture) => texture.height))

      sceneryProps.push(
        ...provisional.tall.map((texture) => ({ texture, height: texture.height / tallestDrawing, framing: true })),
        ...provisional.low.map((texture) => ({ texture, height: texture.height / tallestDrawing, framing: false }))
      )
    }

    const scenery = new BattleScenery(
      sceneSeed,
      battle.biome,
      backgroundId ? (art.get(backgroundId) ?? null) : null,
      sceneryProps,
      provisional.ground,
      {
        // Far, middle and near, each one only if it exists.
        bands: ['far', 'middle', 'near'].map(
          (band) => art.get(landscape.bands.find((id) => id.endsWith(`/${band}`)) ?? '') ?? null
        ),
        landmarks: landscape.landmarks.flatMap((id) => (art.has(id) ? [art.get(id)!] : [])),
        floor: landscape.floor ? (art.get(landscape.floor) ?? null) : null,
        floorLine: landscape.floorLine ?? FLOOR_LINE
      }
    )
    const renderer = new BattleRenderer(app, labels, onTap, art, parts, scenery)

    renderer.resizeObserver = new ResizeObserver(() => app.resize())
    renderer.resizeObserver.observe(element)

    renderer.layout(battle)
    app.renderer.on('resize', () => renderer.layout(renderer.lastBattle ?? battle))

    return renderer
  }

  destroy(): void {
    this.resizeObserver?.disconnect()
    this.particles.destroy()
    // Not `true`: that also releases resources shared with the other PixiJS apps of the page.
    this.app.destroy({ removeView: true }, { children: true })
  }

  private get width(): number {
    return this.app.screen.width
  }

  private get height(): number {
    return this.app.screen.height
  }

  /** Height of the field the HUD leaves free. */
  private get fieldHeight(): number {
    return Math.max(200, this.height - this.insets.top - this.insets.bottom)
  }

  private get scale(): number {
    return Math.max(0.5, Math.min(1.1, this.width / 560, this.fieldHeight / 380))
  }

  /**
   * The ground line, within the free field: low on wide screens, closer to the middle on tall ones, and always
   * leaving room for the front row (46 below it, see spotOf) above the HUD.
   */
  private get groundY(): number {
    const field = this.fieldHeight

    return (
      Math.min(this.height, this.insets.top) +
      Math.min(field * 0.88, field - 54 * this.scale, field / 2 + 230 * this.scale)
    )
  }

  /** Room the HUD covers at the top and the bottom: the fighters move to the free field. */
  setInsets(top: number, bottom: number): void {
    if (top === this.insets.top && bottom === this.insets.bottom) {
      return
    }

    this.insets = { top, bottom }

    if (this.lastBattle) {
      this.layout(this.lastBattle)
    }
  }

  /** The fighters the player can pick now (none when not choosing a target). */
  setTargets(ids: string[]): void {
    this.targetIds = ids
  }

  /** Draws the background and places every fighter at its spot (on start and on resize). */
  layout(battle: BattleState): void {
    this.lastBattle = battle
    this.drawBackground()

    for (const combatant of battle.combatants) {
      this.ensureFigure(combatant, battle)
    }

    this.placeAll(battle)
  }

  private drawBackground(): void {
    this.scenery.layout(this.width, this.height, this.groundY, this.scale)
    this.world.pivot.set(this.width / 2, this.groundY)
    this.world.position.set(this.width / 2, this.groundY)
  }

  /** Spot of a fighter: heroes on the left, enemies on the right, in staggered rows. */
  private spotOf(combatant: Combatant, battle: BattleState): { x: number; y: number } {
    const side = battle.combatants.filter(
      (other) =>
        other.side === combatant.side &&
        (combatant.side === 'hero' ? !other.reserve : other.id.startsWith(combatant.id.split('-')[0]))
    )
    const index = Math.max(
      0,
      side.findIndex((other) => other.id === combatant.id)
    )
    const rows = [0, -46, 46]
    const y = this.groundY + rows[index % 3] * this.scale

    if (combatant.side === 'hero') {
      return { x: this.width * (0.31 - 0.1 * (index % 3)), y }
    }

    return { x: this.width * (0.69 + 0.1 * (index % 3)), y }
  }

  private placeAll(battle: BattleState): void {
    for (const combatant of battle.combatants) {
      const figure = this.figures.get(combatant.id)

      if (!figure) {
        continue
      }

      const spot = this.spotOf(combatant, battle)

      figure.home = spot
      figure.root.position.set(spot.x, spot.y)
      figure.root.scale.set(this.scale)
      figure.root.visible = !(combatant.side === 'hero' && combatant.reserve)

      if (combatant.side === 'enemy' && combatant.id.split('-')[0] !== `e${battle.phase + 1}`) {
        figure.root.visible = false
      }
    }

    this.fighters.children.sort((a, b) => a.y - b.y)
  }

  private ensureFigure(combatant: Combatant, battle: BattleState): Figure {
    const existing = this.figures.get(combatant.id)

    if (existing) {
      return existing
    }

    const size = combatant.side === 'enemy' ? getSpecies(combatant.speciesId!).size * (combatant.elite ? 1.15 : 1) : 1
    const root = new Container()
    const artId =
      combatant.side === 'hero'
        ? figureArtId('hero', combatant.characterId!, false)
        : figureArtId('enemy', combatant.speciesId!, getSpecies(combatant.speciesId!).rarity === 'boss')
    const texture = this.art.get(artId)
    const puppet = rigOf(combatant, artId, this.parts)
    const rig = puppet ? RigFigure.create(puppet, this.parts, this.art, artHeight(combatant.side)) : null
    const body = rig
      ? drawRig(rig, artId)
      : texture
        ? drawArt(texture, combatant.side, artId)
        : combatant.side === 'hero'
          ? drawHero(combatant.characterId!)
          : drawEnemy(combatant)
    const healthBar = new Graphics()
    const statusText = new Text({
      text: '',
      style: { fontFamily: FONT, fontWeight: '900', fontSize: 11, fill: 0xe9d5ff, stroke: { color: OUTLINE, width: 4 } }
    })
    const barsText =
      combatant.bars > 1
        ? new Text({
            text: '',
            style: {
              fontFamily: FONT,
              fontWeight: '900',
              fontSize: 14,
              fill: 0xffc233,
              stroke: { color: OUTLINE, width: 4 }
            }
          })
        : null

    body.scale.set(size)
    healthBar.position.set(0, -FIGURE_HEIGHT * size - 18)
    // Below the feet, so it never covers the numbers that rise over the head.
    statusText.anchor.set(0.5, 0)
    statusText.position.set(0, 10)
    const aura = new StatusAura(
      this.particles,
      body,
      FIGURE_HEIGHT * size * (combatant.side === 'hero' ? 1.1 : 1),
      Math.max(26, shadowOf(artId).radiusX * size * 0.9),
      combatant.side === 'hero' ? 1 : -1,
      -FIGURE_HEIGHT * size - 18,
      this.reducedMotion
    )

    aura.set(combatant.health > 0 ? combatant.statuses.map((status) => status.type) : [])
    const shieldBadge = new Container()
    const shieldText = new Text({
      text: '',
      style: { fontFamily: FONT, fontWeight: '900', fontSize: 13, fill: 0xffffff, stroke: { color: OUTLINE, width: 4 } }
    })

    shieldBadge.addChild(drawShieldIcon(), shieldText)
    shieldText.anchor.set(0.5)
    shieldText.position.set(0, 0)
    shieldBadge.position.set(-52, -FIGURE_HEIGHT * size - 14)
    shieldBadge.visible = false
    root.addChild(aura.back, body, aura.front, healthBar, shieldBadge, statusText)

    if (barsText) {
      barsText.anchor.set(0, 0.5)
      barsText.position.set(44, -FIGURE_HEIGHT * size - 14)
      root.addChild(barsText)
    }

    root.eventMode = 'static'
    root.cursor = 'pointer'
    root.on('pointertap', () => this.onTap(combatant.id))

    const figure: Figure = {
      id: combatant.id,
      root,
      body,
      healthBar,
      barsText,
      shieldBadge,
      shieldText,
      shields: combatant.shields ?? 0,
      statusText,
      aura,
      side: combatant.side,
      rig,
      style: styleOf(combatant),
      orbs: null,
      size,
      shadow: shadowOf(artId),
      health: combatant.health,
      maxHealth: combatant.stats.maxHealth,
      bars: combatant.bars,
      home: this.spotOf(combatant, battle)
    }

    this.figures.set(combatant.id, figure)
    this.fighters.addChild(root)
    this.drawHealth(figure)
    this.drawShields(figure)

    if (combatant.health <= 0) {
      root.alpha = 0.35
      body.rotation = combatant.side === 'hero' ? -1.2 : 1.2
    }

    return figure
  }

  private drawHealth(figure: Figure): void {
    const width = 76
    const share = Math.max(0, figure.health / figure.maxHealth)
    const g = figure.healthBar

    g.clear()
    g.roundRect(-width / 2 - 3, -3, width + 6, 14, 6).fill({ color: OUTLINE })
    g.roundRect(-width / 2, 0, width * share, 8, 4).fill({
      color: figure.side === 'hero' ? 0x84f06b : share < 0.3 ? 0xff4d8d : 0xd7263d
    })

    if (figure.barsText) {
      figure.barsText.text = figure.bars > 1 ? `×${figure.bars}` : ''
    }
  }

  /** The number of shields beside the health bar (like the health bar, only while it stands). */
  private drawShields(figure: Figure): void {
    figure.shieldText.text = String(figure.shields)
    figure.shieldBadge.visible = figure.shields > 0 && figure.healthBar.visible !== false && figure.health > 0
  }

  /** Brings the drawing in line with the state (statuses, health, who is on the field, the marked fighter). */
  sync(battle: BattleState, markedId: string | null): void {
    this.markedId = markedId
    this.lastBattle = battle

    for (const combatant of battle.combatants) {
      const figure = this.ensureFigure(combatant, battle)

      figure.health = combatant.health
      figure.maxHealth = combatant.stats.maxHealth
      figure.bars = combatant.bars
      figure.statusText.text = combatant.statuses.map((status) => this.labels.status(status.type)).join(' · ')
      figure.aura.set(combatant.health > 0 ? combatant.statuses.map((status) => status.type) : [])
      this.drawHealth(figure)
      figure.healthBar.visible = combatant.health > 0
      figure.shields = combatant.health > 0 ? (combatant.shields ?? 0) : 0
      this.drawShields(figure)
      this.drawOrbs(figure, combatant.health > 0 ? (combatant.charges ?? []) : [])
    }

    this.placeAll(battle)
  }

  /** Animates the events of a step of the battle, in order. */
  async play(events: BattleEvent[], after: BattleState): Promise<void> {
    for (const [index, event] of events.entries()) {
      await this.playEvent(event, after, event.type === 'action' ? outcomesOf(events, index) : undefined)
    }

    this.focus(null)
  }

  /** Leans the camera towards a spot of the stage (a little closer), or back to the whole field. */
  private focus(x: number | null, zoom = 1.05): void {
    const limit = this.width * MAX_PAN

    this.camera.targetX = x === null ? 0 : Math.max(-limit, Math.min(limit, (x - this.width / 2) * 0.3))
    this.camera.targetZoom = x === null ? 1 : zoom
  }

  private async playEvent(
    event: BattleEvent,
    after: BattleState,
    outcomes = new Map<string, HitOutcome>()
  ): Promise<void> {
    const ms = (value: number) => value / this.speed
    const sound = soundOf(event, 'targetId' in event ? (this.figures.get(event.targetId)?.side ?? null) : null)

    if (sound) {
      playSfx(sound)
    }

    switch (event.type) {
      case 'turn': {
        const figure = this.figures.get(event.actorId)

        if (figure) {
          await this.tween(ms(160), (t) => figure.body.position.set(0, -Math.sin(t * Math.PI) * 10))
        }

        break
      }

      case 'action': {
        const actor = this.figures.get(event.actorId)
        const target = this.figures.get(event.targetIds[0])

        if (!actor) {
          break
        }

        const skill = getSkill(event.skillId)
        const effect = attackEffectOf(skill, actor.style, actor.side)
        const targets = event.targetIds
          .map((id) => this.figures.get(id))
          .filter((figure): figure is Figure => !!figure && figure.root.visible)
        const foes = targets.filter((figure) => figure.side !== actor.side)

        this.float(actor, this.labels.skill(event.skillId), 0xffffff, 15, -40)
        this.focus(target && target.side !== actor.side ? (actor.home.x + target.home.x) / 2 : actor.home.x)

        if (skill.consumes === 'charges') {
          this.spendCharges(actor)
        }

        if (effect.delivery === 'aura' || foes.length === 0) {
          await this.cast(actor, effect)
          await this.visuals.deliver(
            effect,
            this.sourceOf(actor),
            targets.map((figure) => this.effectTarget(figure)),
            outcomes
          )
        } else if (effect.approach === 'shoot') {
          await this.shoot(actor, foes, arrowKindOf(skill), skill.target === TargetType.ALL_ENEMIES, effect, outcomes)
        } else if (effect.approach === 'lunge') {
          await this.lunge(actor, foes, effect, outcomes)
        } else {
          await this.cast(actor, effect)
          await this.visuals.deliver(
            effect,
            this.sourceOf(actor),
            foes.map((figure) => this.effectTarget(figure)),
            outcomes
          )
        }

        break
      }

      case 'damage':

      case 'statusTick': {
        const figure = this.figures.get(event.targetId)

        if (!figure) {
          break
        }

        figure.health = Math.max(0, figure.health - event.amount)
        this.drawHealth(figure)

        if (event.type === 'statusTick') {
          this.visuals.statusTick(event.status, this.effectTarget(figure))
        }

        const critical = event.type === 'damage' && event.critical
        const color =
          event.type === 'statusTick'
            ? event.status === StatusType.POISON
              ? 0xa3e635
              : 0xff8a00
            : critical
              ? 0xffc233
              : (DAMAGE_COLORS[event.damageType] ?? 0xffffff)

        this.float(figure, critical ? `${event.amount}!` : String(event.amount), color, critical ? 30 : 22)

        if (event.type === 'damage' && event.weak) {
          this.float(figure, this.labels.weak, 0xffc233, 14, -26)
        }

        if (event.type === 'damage' && event.resisted) {
          this.float(figure, this.labels.resist, 0x9ca3af, 14, -26)
        }

        if (critical) {
          void this.shake(ms(240), 7)
        }

        await this.hit(figure, ms(220))
        break
      }

      case 'item': {
        const actor = this.figures.get(event.actorId)

        if (actor) {
          this.float(actor, this.labels.item(event.itemId), 0xffc233, 15, -40)
          actor.rig?.play('cast', ms(420))
          await this.tween(ms(260), (t) => actor.body.scale.set(actor.size * (1 + Math.sin(t * Math.PI) * 0.12)))
        }

        break
      }

      case 'revive': {
        const figure = this.figures.get(event.targetId)

        if (!figure) {
          break
        }

        const rotation = figure.body.rotation

        figure.health = event.amount
        figure.healthBar.visible = true
        this.drawHealth(figure)
        await this.tween(ms(380), (t) => {
          figure.body.rotation = rotation * (1 - t)
          figure.root.alpha = 0.35 + 0.65 * t
        })
        this.float(figure, `+${event.amount}`, 0x84f06b, 22)
        break
      }

      case 'stance': {
        const figure = this.figures.get(event.targetId)

        if (figure) {
          this.float(figure, this.labels.stance(event.stance), 0xffc233, 14, -28)
        }

        await wait(ms(220))
        break
      }

      case 'focus': {
        const figure = this.figures.get(event.targetId)

        if (figure) {
          this.float(figure, `+${event.amount}`, 0x22d3ee, 18)
        }

        await wait(ms(220))
        break
      }

      case 'heal': {
        const figure = this.figures.get(event.targetId)

        if (!figure) {
          break
        }

        figure.health = Math.min(figure.maxHealth, figure.health + event.amount)
        this.drawHealth(figure)
        this.float(figure, `+${event.amount}`, 0x84f06b, 22)
        await wait(ms(260))
        break
      }

      case 'shields': {
        const figure = this.figures.get(event.targetId)

        if (!figure) {
          break
        }

        figure.shields = event.shields
        this.drawShields(figure)

        if (event.change < 0) {
          // The shield takes the whole hit and breaks: a flash of blue, the badge jolts.
          this.float(figure, this.labels.shieldBlock, 0x8fd3ff, 18, -20)
          void this.shake(ms(160), 3)
          await this.tween(ms(260), (t) => {
            const pulse = 1 + Math.sin(t * Math.PI) * 0.6

            figure.shieldBadge.scale.set(pulse)
            figure.body.tint = t < 0.5 ? 0x9fd8ff : 0xffffff
          })
          figure.shieldBadge.scale.set(1)
          figure.body.tint = 0xffffff
        } else {
          this.float(figure, this.labels.shieldGain(event.change), 0x8fd3ff, 15, -28)
          await this.tween(ms(240), (t) => figure.shieldBadge.scale.set(1 + Math.sin(t * Math.PI) * 0.5))
          figure.shieldBadge.scale.set(1)
        }

        break
      }

      case 'perk': {
        const figure = this.figures.get(event.targetId)

        if (figure) {
          this.float(figure, this.labels.perk(event.perk), 0xffd23c, 14, -30)
        }

        await wait(ms(240))
        break
      }

      case 'miss':

      case 'immune': {
        const figure = this.figures.get(event.targetId)

        if (figure) {
          this.float(figure, event.type === 'miss' ? this.labels.miss : this.labels.immune, 0xd1d5db, 16)
        }

        await wait(ms(260))
        break
      }

      case 'status':

      case 'skip': {
        const id = event.type === 'status' ? event.targetId : event.actorId
        const figure = this.figures.get(id)

        if (figure) {
          this.float(figure, this.labels.status(event.status), STATUS_COLORS[event.status].light, 14, -28)

          if (event.type === 'status') {
            // It shows on the fighter from now on (the next sync confirms it).
            figure.aura.add(event.status)
          } else if (!this.reducedMotion) {
            // Losing its turn: it shudders in its ice or reels under its stars.
            await this.tween(ms(360), (t) => {
              figure.body.position.x = Math.sin(t * Math.PI * 6) * 3 * (1 - t)
            })
          }
        }

        await wait(ms(event.type === 'skip' ? 420 : 200))
        break
      }

      case 'statusEnd': {
        this.figures.get(event.targetId)?.aura.remove(event.status)
        break
      }

      case 'fall': {
        const figure = this.figures.get(event.targetId)

        if (!figure) {
          break
        }

        figure.aura.set([])
        figure.shields = 0
        this.drawShields(figure)

        const direction = figure.side === 'hero' ? -1 : 1

        await this.tween(ms(380), (t) => {
          figure.body.rotation = direction * 1.2 * t
          figure.root.alpha = 1 - 0.65 * t
        })
        break
      }

      case 'nextBar': {
        const figure = this.figures.get(event.targetId)

        if (!figure) {
          break
        }

        figure.bars = event.bars
        figure.health = figure.maxHealth
        this.float(figure, this.labels.transform, 0xff4d8d, 18, -30)
        void this.shake(ms(500), 10)
        await this.tween(ms(500), (t) => {
          figure.body.scale.set(figure.size * (1 + Math.sin(t * Math.PI) * 0.25))
          figure.body.tint = t < 0.5 ? 0xff7777 : 0xffffff
        })
        figure.size *= 1.08
        figure.body.scale.set(figure.size)
        this.drawHealth(figure)
        break
      }

      case 'phase': {
        if (event.phase === 0) {
          break
        }

        this.sync(after, null)

        const entering = event.enemyIds.map((id) => this.figures.get(id)!).filter(Boolean)

        for (const figure of entering) {
          figure.root.visible = true
        }

        await this.tween(ms(500), (t) => {
          for (const figure of entering) {
            figure.root.position.x = figure.home.x + (1 - ease(t)) * this.width * 0.4
          }
        })
        break
      }

      case 'reserves': {
        this.sync(after, null)

        const entering = event.heroIds.map((id) => this.figures.get(id)!).filter(Boolean)

        await this.tween(ms(500), (t) => {
          for (const figure of entering) {
            figure.root.position.x = figure.home.x - (1 - ease(t)) * this.width * 0.4
          }
        })
        break
      }

      default:
        break
    }
  }

  /**
   * A shot from where the shooter stands: it leans back drawing the string,
   * lets go with a small recoil and the arrows (drawn by code, see arrows.ts)
   * fly to their targets, one after the other, high when they rain on every
   * enemy. It ends when the last one lands, so the damage shows on impact.
   */
  private async shoot(
    actor: Figure,
    targets: Figure[],
    kind: ArrowKind,
    volley: boolean,
    effect: AttackEffect,
    outcomes: Map<string, HitOutcome>
  ): Promise<void> {
    const ms = (value: number) => value / this.speed
    const direction = actor.side === 'hero' ? 1 : -1

    actor.rig?.play('shoot', ms(460))

    // Drawing the string: back and leaning away from the target.
    await this.tween(ms(240), (t) => {
      actor.body.position.x = -6 * direction * ease(t)
      actor.body.rotation = -0.05 * direction * ease(t)
    })

    // The release: a quick snap forward, then back to rest while the arrows fly.
    void this.tween(ms(220), (t) => {
      // From drawn (-6) past rest (+3) in the first quarter, then easing back to 0.
      const snap = t < 0.25 ? -6 + 9 * (t / 0.25) : 3 * (1 - ease((t - 0.25) / 0.75))

      actor.body.position.x = snap * direction
      actor.body.rotation = (snap / 6) * 0.05 * direction
    }).then(() => {
      actor.body.position.x = 0
      actor.body.rotation = 0
    })

    await Promise.all(
      targets.map((target, index) =>
        wait(ms(index * 70)).then(() =>
          this.flyArrow(actor, target, kind, volley, direction).then(() =>
            this.visuals.impact(effect, this.effectTarget(target), outcomes.get(target.id), direction)
          )
        )
      )
    )
  }

  /** One arrow from the bow of `from` to the chest of `to`, along a low arc (a high one in a volley). */
  private async flyArrow(from: Figure, to: Figure, kind: ArrowKind, volley: boolean, direction: number): Promise<void> {
    const ms = (value: number) => value / this.speed
    const scale = this.scale
    const start = {
      x: from.root.position.x + 26 * direction * scale,
      y: from.root.position.y - FIGURE_HEIGHT * from.size * 0.58 * scale
    }
    const end = {
      x: to.root.position.x - 14 * direction * to.size * scale,
      y: to.root.position.y - FIGURE_HEIGHT * to.size * 0.5 * scale
    }
    const distance = Math.hypot(end.x - start.x, end.y - start.y)
    const lift = distance * (volley ? 0.32 : 0.07)
    const at = (t: number) => ({
      x: start.x + (end.x - start.x) * t,
      y: start.y + (end.y - start.y) * t - Math.sin(t * Math.PI) * lift
    })
    const arrow = drawArrow(kind, 50 * scale)
    const trail = new Graphics()
    const points: { x: number; y: number }[] = []

    this.effects.addChild(trail, arrow)

    await this.tween(ms(Math.min(320, 150 + distance * 0.22) * (volley ? 1.3 : 1)), (t) => {
      const here = at(t)
      const ahead = at(Math.min(1, t + 0.02))
      const behind = at(Math.max(0, t - 0.02))

      arrow.position.set(here.x, here.y)
      arrow.rotation = Math.atan2(ahead.y - behind.y, ahead.x - behind.x)
      points.push(here)

      if (points.length > 8) {
        points.shift()
      }

      drawTrail(trail, points, kind, 8 * scale)
    })

    trail.destroy()

    // The impact: a flash, and the arrow stays stuck for a moment before it fades.
    const impact = new Graphics()

    impact.position.set(end.x, end.y)
    this.effects.addChild(impact)
    void this.tween(ms(260), (t) => drawImpact(impact, kind, 26 * scale, t)).then(() => impact.destroy())
    void this.tween(ms(300), (t) => {
      arrow.alpha = t < 0.4 ? 1 : 1 - (t - 0.4) / 0.6
    }).then(() => arrow.destroy({ children: true }))
  }

  /**
   * A blow up close: the fighter closes in (a puppet winds up on the way), the
   * mark of the blow lands on every target and it goes back to its spot.
   */
  private async lunge(
    actor: Figure,
    targets: Figure[],
    effect: AttackEffect,
    outcomes: Map<string, HitOutcome>
  ): Promise<void> {
    const ms = (value: number) => value / this.speed
    const target = targets[0]
    const dx = (target.home.x - actor.home.x) * 0.55
    const dy = (target.home.y - actor.home.y) * 0.55

    actor.rig?.play('attack', ms(560))
    await this.tween(ms(actor.rig ? 250 : 170), (t) =>
      actor.root.position.set(actor.home.x + dx * ease(t), actor.home.y + dy * ease(t))
    )

    if (actor.rig) {
      await wait(ms(110))
    }

    await this.visuals.deliver(
      effect,
      this.sourceOf(actor),
      targets.map((figure) => this.effectTarget(figure)),
      outcomes
    )
    void this.tween(ms(220), (t) =>
      actor.root.position.set(actor.home.x + dx * (1 - ease(t)), actor.home.y + dy * (1 - ease(t)))
    )
  }

  /** A spell from its spot: the puppet raises its hands (or the figure swells) behind a circle of runes. */
  private async cast(actor: Figure, effect: AttackEffect): Promise<void> {
    const ms = (value: number) => value / this.speed
    const source = this.sourceOf(actor)

    if (effect.delivery !== 'aura' && effect.delivery !== 'breath') {
      void this.visuals.castCircle(effect.look, source.hand, source.direction, effect.scale)
    }

    if (actor.rig) {
      actor.rig.play('cast', ms(420))
      await wait(ms(260))
    } else {
      await this.tween(ms(240), (t) => actor.body.scale.set(actor.size * (1 + Math.sin(t * Math.PI) * 0.12)))
    }
  }

  /** Where the effects of a fighter leave from: its hand (or mouth), in front of it at chest height. */
  private sourceOf(figure: Figure): { hand: { x: number; y: number }; direction: 1 | -1 } {
    const direction = figure.side === 'hero' ? 1 : -1
    const scale = figure.size * this.scale

    return {
      hand: {
        x: figure.root.position.x + 30 * direction * scale,
        y: figure.root.position.y - FIGURE_HEIGHT * scale * 0.6
      },
      direction
    }
  }

  private effectTarget(figure: Figure): EffectTarget {
    const height = FIGURE_HEIGHT * figure.size * this.scale

    return {
      id: figure.id,
      chest: { x: figure.root.position.x, y: figure.root.position.y - height * 0.5 },
      feet: { x: figure.root.position.x, y: figure.root.position.y },
      height
    }
  }

  /** A flash over the whole screen (soft when the player asked for less motion). */
  private flash(color: number, alpha: number, duration: number): void {
    const strength = Math.min(0.5, alpha) * (this.reducedMotion ? 0.35 : 1)

    this.flashLayer.clear().rect(0, 0, this.width, this.height).fill({ color })
    this.flashLayer.blendMode = 'add'
    void this.tween(duration, (t) => {
      this.flashLayer.alpha = strength * (1 - t)
    })
  }

  /** The charges of the fighter fly into its spell, and their orbs go out until the next sync. */
  private spendCharges(figure: Figure): void {
    if (!figure.orbs) {
      return
    }

    const hand = this.sourceOf(figure).hand

    for (const orb of figure.orbs.children) {
      const at = figure.root.toGlobal(orb.position)
      const local = this.particles.view.toLocal(at)

      this.visuals.stream(local, hand, Number(orb.label))
    }

    figure.orbs.removeChildren().forEach((orb) => orb.destroy())
  }

  /** One orb for each elemental charge, of its color, going round the fighter. */
  private drawOrbs(figure: Figure, charges: DamageType[]): void {
    if (!figure.orbs) {
      if (charges.length === 0) {
        return
      }

      figure.orbs = new Container()
      figure.root.addChild(figure.orbs)
    }

    const colors = charges.map((charge) => LOOK_COLORS[charge].glow)
    const current = figure.orbs.children.map((orb) => orb.label)

    if (current.length === colors.length && current.every((label, index) => label === String(colors[index]))) {
      return
    }

    figure.orbs.removeChildren().forEach((orb) => orb.destroy())

    for (const color of colors) {
      const orb = new Graphics()

      orb.label = String(color)
      orb.circle(0, 0, 14).fill({ color, alpha: 0.3 })
      orb.circle(0, 0, 8.5).fill({ color }).stroke({ width: 2.5, color: OUTLINE })
      orb.circle(-2.5, -2.5, 3).fill({ color: 0xffffff })
      figure.orbs.addChild(orb)
    }
  }

  /** The orbs go round the middle of the body, dimmer when they pass behind it. */
  private moveOrbs(figure: Figure): void {
    const orbs = figure.orbs?.children ?? []

    orbs.forEach((orb, index) => {
      const angle = this.elapsed * 2.2 + (index / orbs.length) * Math.PI * 2
      const depth = Math.sin(angle)

      orb.position.set(Math.cos(angle) * 40 * figure.size, -FIGURE_HEIGHT * figure.size * 0.55 + depth * 10)
      orb.alpha = 0.55 + depth * 0.4
      orb.scale.set(1 + depth * 0.2 + Math.sin(this.elapsed * 9 + index) * 0.06)
    })
  }

  /** When the frames slow down for a while, the effects drop to their light quality (and stay there). */
  private watchFrames(deltaMS: number): void {
    this.frameTime = this.frameTime * 0.95 + Math.min(100, deltaMS) * 0.05

    if (this.particles.quality === 'high' && this.frameTime > 24 && this.elapsed > 3) {
      this.particles.quality = 'low'
    }
  }

  private hit(figure: Figure, duration: number): Promise<void> {
    const direction = figure.side === 'hero' ? -1 : 1

    figure.rig?.play('hit', duration * 2)

    return this.tween(duration, (t) => {
      figure.body.alpha = t < 0.35 ? 0.55 : 1
      figure.body.position.x = Math.sin(t * Math.PI * 4) * 6 * direction * (1 - t)
    })
  }

  /** A text that rises and fades over a fighter. */
  private float(figure: Figure, text: string, color: number, size: number, offset = 0): void {
    const label = new Text({
      text,
      style: { fontFamily: FONT, fontWeight: '900', fontSize: size, fill: color, stroke: { color: OUTLINE, width: 5 } }
    })
    const start = {
      x: figure.root.position.x + (Math.random() - 0.5) * 20,
      y: figure.root.position.y - FIGURE_HEIGHT * figure.size * this.scale * 0.7 + offset
    }

    label.anchor.set(0.5)
    label.position.set(start.x, start.y)
    label.scale.set(Math.max(0.8, this.scale))
    this.effects.addChild(label)
    void this.tween(900 / this.speed, (t) => {
      label.position.y = start.y - 46 * t
      label.alpha = t < 0.7 ? 1 : 1 - (t - 0.7) / 0.3
    }).then(() => label.destroy())
  }

  private shake(duration: number, strength: number): Promise<void> {
    if (this.reducedMotion) {
      return Promise.resolve()
    }

    return this.tween(duration, (t) => {
      const amount = strength * (1 - t)

      this.stage.position.set((Math.random() - 0.5) * amount, (Math.random() - 0.5) * amount)
    }).then(() => {
      this.stage.position.set(0, 0)
    })
  }

  private tween(duration: number, update: (t: number) => void): Promise<void> {
    return new Promise((resolve) => {
      let time = 0

      const step = (ticker: { deltaMS: number }) => {
        time += ticker.deltaMS
        const t = Math.min(1, time / Math.max(1, duration))

        update(t)

        if (t >= 1) {
          this.app.ticker.remove(step)
          resolve()
        }
      }

      this.app.ticker.add(step)
    })
  }

  /**
   * Every frame: the camera eases towards its target with a slow sway, the
   * scenery follows it by depth, the marked fighter (whose turn it is, or the
   * chosen target) gets a ring at its feet and everybody breathes.
   */
  private animate(deltaMS: number): void {
    this.elapsed += deltaMS / 1000
    this.marker.clear()

    const ease = Math.min(1, (deltaMS / 1000) * 3 * this.speed)
    const sway = Math.sin(this.elapsed * 0.25) * this.width * 0.012

    this.camera.x += (this.camera.targetX + sway - this.camera.x) * ease
    this.camera.zoom += (this.camera.targetZoom - this.camera.zoom) * ease
    this.world.scale.set(this.camera.zoom)
    this.fighters.x = this.marker.x = this.effects.x = this.groundEffects.x = this.particles.view.x = -this.camera.x
    this.particles.update(deltaMS * this.speed)
    this.watchFrames(deltaMS)
    this.scenery.update(deltaMS, this.camera.x)

    const marked = this.markedId ? this.figures.get(this.markedId) : null

    if (marked && marked.root.visible) {
      const pulse = 1 + Math.sin(this.elapsed * 5) * 0.08
      const { x, y, radiusX, radiusY } = marked.shadow
      const scale = marked.size * this.scale

      this.marker
        .ellipse(
          marked.root.position.x + x * scale,
          marked.root.position.y + (y + 4) * scale,
          radiusX * 1.15 * scale * pulse,
          radiusY * 1.4 * scale * pulse
        )
        .stroke({ width: 4, color: marked.side === 'hero' ? 0xffc233 : 0xff4d8d })
    }

    // The fighters that can be picked: a ring at the feet and an arrow bobbing over the head.
    for (const id of this.targetIds) {
      const target = this.figures.get(id)

      if (!target || !target.root.visible) {
        continue
      }

      const color = target.side === 'enemy' ? 0xff4d8d : 0x84f06b
      const { x, y } = target.root.position
      const shadow = target.shadow
      const scale = target.size * this.scale
      const top = y - (FIGURE_HEIGHT * target.size + 34) * this.scale - Math.abs(Math.sin(this.elapsed * 4)) * 10
      const arrow = 11 * this.scale

      this.marker
        .ellipse(
          x + shadow.x * scale,
          y + (shadow.y + 4) * scale,
          shadow.radiusX * 1.05 * scale,
          shadow.radiusY * 1.26 * scale
        )
        .fill({ color, alpha: 0.18 + Math.sin(this.elapsed * 5) * 0.08 })
        .stroke({ width: 3, color, alpha: 0.9 })
      this.marker
        .poly([x - arrow, top - arrow * 1.3, x + arrow, top - arrow * 1.3, x, top])
        .fill({ color })
        .stroke({ width: 3, color: OUTLINE })
    }

    for (const [, figure] of this.figures) {
      const pace = figure.aura.pace
      const { x, y } = figure.root.position

      this.moveOrbs(figure)
      figure.aura.update(deltaMS * this.speed, figure.root.visible ? { x, y, scale: this.scale } : null)

      if (figure.rig) {
        figure.rig.update(deltaMS * pace)
      } else if (figure.root.alpha === 1 && pace > 0) {
        figure.body.scale.y = figure.size * (1 + Math.sin(this.elapsed * 2.4 + figure.home.x) * 0.015)
      }
    }
  }
}

function ease(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2
}

function mix(a: number, b: number, share: number): number {
  const channel = (shift: number) => Math.round(((a >> shift) & 0xff) * (1 - share) + ((b >> shift) & 0xff) * share)

  return (channel(16) << 16) | (channel(8) << 8) | channel(0)
}

/** How tall the final art stands: heroes a bit taller than a common enemy of size 1. */
export function artHeight(side: Combatant['side']): number {
  return FIGURE_HEIGHT * (side === 'hero' ? 1.15 : 1)
}

/** The shadow at the feet, with the adjustment of each figure (see data/shadows). */
function drawShadow(artId: string): Graphics {
  const { x, y, radiusX, radiusY } = shadowOf(artId)

  return new Graphics().ellipse(x, y, radiusX, radiusY).fill({ color: 0x000000, alpha: SHADOW_ALPHA })
}

/** A fighter with its final art: the figure standing on its spot, with a shadow at its feet. */
export function drawArt(texture: Texture, side: Combatant['side'], artId: string): Container {
  const container = new Container()
  const sprite = new Sprite(texture)

  sprite.anchor.set(0.5, 0.97)
  sprite.scale.set(artHeight(side) / texture.height)
  container.addChild(drawShadow(artId), sprite)

  return container
}

/** A fighter put together from its parts sheet (it animates itself). */
export function drawRig(rig: RigFigure, artId: string): Container {
  const container = new Container()

  container.addChild(drawShadow(artId), rig.view)

  return container
}

/** Provisional hero: a figure facing right with its weapon. */
export function drawHero(characterId: CharacterId): Container {
  const color = getCharacterDefinition(characterId).color
  const container = new Container()
  const g = new Graphics()
  const stroke = { width: 4, color: OUTLINE }

  // Shadow, legs, body, head.
  g.ellipse(0, 0, 30, 8).fill({ color: 0x000000, alpha: 0.35 })
  g.roundRect(-14, -40, 11, 40, 4)
    .fill({ color: mix(color, 0x000000, 0.5) })
    .stroke(stroke)
  g.roundRect(3, -40, 11, 40, 4)
    .fill({ color: mix(color, 0x000000, 0.5) })
    .stroke(stroke)
  g.roundRect(-20, -88, 40, 52, 10).fill({ color }).stroke(stroke)
  g.circle(0, -102, 15).fill({ color: 0xf2c9a0 }).stroke(stroke)
  g.rect(4, -106, 5, 5).fill({ color: OUTLINE })

  switch (characterId) {
    case CharacterId.KAEL:
      g.roundRect(18, -110, 7, 62, 2).fill({ color: 0xe5e7eb }).stroke(stroke)
      g.rect(12, -52, 19, 6).fill({ color: 0xffc233 }).stroke(stroke)
      break
    case CharacterId.SERA:
      g.arc(26, -70, 34, -1.2, 1.2).stroke({ width: 6, color: 0x8b5a2b })
      g.moveTo(38, -101).lineTo(38, -39).stroke({ width: 2, color: 0xe5e7eb })
      break
    case CharacterId.BRANN:
      g.roundRect(18, -112, 6, 72, 2).fill({ color: 0x8b5a2b }).stroke(stroke)
      g.poly([24, -112, 50, -104, 50, -84, 24, -92]).fill({ color: 0xd1d5db }).stroke(stroke)
      break
    case CharacterId.OREN:
      g.roundRect(20, -120, 6, 120, 2).fill({ color: 0x6b4423 }).stroke(stroke)
      g.circle(23, -124, 9).fill({ color: 0x84cc16 }).stroke(stroke)
      break
    case CharacterId.YSOLDE:
      g.roundRect(20, -118, 6, 118, 2).fill({ color: 0x3b2f5c }).stroke(stroke)
      g.circle(23, -124, 11).fill({ color: 0xc084fc }).stroke(stroke)
      break
  }

  container.addChild(g)

  return container
}

/** Provisional enemy: a shape by archetype, in the color of its species, facing left. */
export function drawEnemy(combatant: Combatant): Container {
  const species = getSpecies(combatant.speciesId!)
  const color = species.color
  const container = new Container()
  const g = new Graphics()
  const stroke = { width: 4, color: OUTLINE }

  const eye = (x: number, y: number) => {
    g.circle(x, y, 6).fill({ color: 0xffffff }).stroke({ width: 2, color: OUTLINE })
    g.circle(x - 2, y, 3).fill({ color: combatant.elite || species.strength > 1 ? 0xff2a2a : OUTLINE })
  }

  g.ellipse(0, 0, 38, 10).fill({ color: 0x000000, alpha: 0.35 })

  switch (species.archetype) {
    case Archetype.BRUTE:
      g.ellipse(0, -46, 44, 40).fill({ color }).stroke(stroke)
      g.poly([-30, -78, -42, -104, -18, -84]).fill({ color: 0xf3e2b3 }).stroke(stroke)
      g.poly([22, -82, 30, -108, 40, -78]).fill({ color: 0xf3e2b3 }).stroke(stroke)
      eye(-20, -56)
      eye(2, -58)
      g.roundRect(-34, -12, 16, 14, 4)
        .fill({ color: mix(color, 0x000000, 0.4) })
        .stroke(stroke)
      g.roundRect(18, -12, 16, 14, 4)
        .fill({ color: mix(color, 0x000000, 0.4) })
        .stroke(stroke)
      break
    case Archetype.AGILE:
      g.poly([-40, -40, 0, -96, 36, -30, 10, 0, -24, 0]).fill({ color }).stroke(stroke)
      eye(-14, -58)
      g.poly([-40, -40, -58, -36, -40, -30]).fill({ color: 0xf3e2b3 }).stroke(stroke)
      break
    case Archetype.TANK:
      g.roundRect(-42, -96, 84, 96, 12).fill({ color }).stroke(stroke)
      g.rect(-42, -60, 84, 10).fill({ color: mix(color, 0x000000, 0.35) })
      eye(-18, -74)
      eye(6, -74)
      break
    case Archetype.CASTER:
      g.circle(0, -70, 34).fill({ color, alpha: 0.25 })
      g.poly([0, -120, 30, -70, 0, -22, -30, -70]).fill({ color }).stroke(stroke)
      eye(-8, -74)
      break
    case Archetype.HEALER:
      g.ellipse(-30, -66, 22, 12).fill({ color: 0xfff7c2, alpha: 0.8 }).stroke(stroke)
      g.ellipse(30, -66, 22, 12).fill({ color: 0xfff7c2, alpha: 0.8 }).stroke(stroke)
      g.circle(0, -58, 26).fill({ color }).stroke(stroke)
      eye(-10, -62)
      break
  }

  if (species.strength > 1) {
    const top = species.archetype === Archetype.CASTER ? -126 : -104

    g.poly([-20, top, -12, top - 18, 0, top - 6, 12, top - 18, 20, top])
      .fill({ color: 0xffc233 })
      .stroke(stroke)
  }

  container.addChild(g)

  return container
}

/** The provisional scenery drawings, painted at twice their size once for every battle. */
let provisionalTextures: SceneryTextures | null = null

function provisionalScenery(): SceneryTextures {
  provisionalTextures ??= paintSceneryTextures(2)

  return provisionalTextures
}

/** How a fighter fights: Ysolde casts from her spot, the heroes with bows shoot, the rest walk up (see attackEffects). */
function styleOf(combatant: Combatant): ActorStyle {
  if (combatant.side !== 'hero') {
    return 'melee'
  }

  if (combatant.characterId === CharacterId.YSOLDE) {
    return 'mage'
  }

  return combatant.weaponId && getWeapon(combatant.weaponId).ranged ? 'archer' : 'melee'
}

/** What happened to each target of the action at `index`: the events that follow it until the next action. */
function outcomesOf(events: BattleEvent[], index: number): Map<string, HitOutcome> {
  const outcomes = new Map<string, HitOutcome>()

  for (const event of events.slice(index + 1)) {
    if (event.type === 'action' || event.type === 'turn' || event.type === 'item') {
      break
    }

    if ((event.type === 'damage' || (event.type === 'shields' && event.change < 0)) && !outcomes.has(event.targetId)) {
      outcomes.set(event.targetId, { missed: false, critical: event.type === 'damage' && event.critical })
    } else if ((event.type === 'miss' || event.type === 'immune') && !outcomes.has(event.targetId)) {
      outcomes.set(event.targetId, { missed: true, critical: false })
    }
  }

  return outcomes
}
