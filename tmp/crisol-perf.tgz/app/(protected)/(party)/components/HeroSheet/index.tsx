'use client'

import './index.scss'
import AddIcon from '@mui/icons-material/Add'
import ChevronLeftIcon from '@mui/icons-material/ChevronLeft'
import ChevronRightIcon from '@mui/icons-material/ChevronRight'
import CloseIcon from '@mui/icons-material/Close'
import ButtonBase from '@mui/material/ButtonBase'
import IconButton from '@mui/material/IconButton'
import Tooltip from '@mui/material/Tooltip'
import classNames from 'classnames'
import { useArtImages } from '@/app/(protected)/(art)/hooks/useArtImages'
import { artUrl } from '@/app/(protected)/(art)/utils/art'
import { getSkill } from '@/app/(protected)/(engine)/data/skills'
import {
  getCharacterWeapons,
  getUpgradeCost,
  MAX_WEAPON_LEVEL,
  WEAPON_POWER_PER_LEVEL
} from '@/app/(protected)/(engine)/data/weapons'
import { CharacterState } from '@/app/(protected)/(engine)/models/CharacterState'
import { CombatStats } from '@/app/(protected)/(engine)/models/CombatStats'
import { GameState } from '@/app/(protected)/(engine)/models/GameState'
import { ACTIVE_HEROES } from '@/app/(protected)/(engine)/utils/battle'
import {
  canForgetSkills,
  canUpgradeWeapon,
  equipSkill,
  equipWeapon,
  getAttributePoints,
  getCharacterStats,
  getKnownSkills,
  getMaxHealth,
  getSkillLevel,
  getSkillPoints,
  getWeaponLevel,
  isTreeComplete,
  moveInFormation,
  SKILL_SLOTS,
  spendAttributePoint,
  spendTear,
  TRADE_ECHOES,
  tradeSkillPoint,
  unequipSkill,
  upgradeWeapon
} from '@/app/(protected)/(engine)/utils/heroes'
import { xpToNextLevel } from '@/app/(protected)/(engine)/utils/progression'
import { getFocus } from '@/app/(protected)/(engine)/utils/worldMap'
import RunesPanel from '@/app/(protected)/(party)/components/RunesPanel'
import SkillIcon from '@/app/(protected)/(party)/components/SkillIcon'
import SkillTree from '@/app/(protected)/(party)/components/SkillTree'
import WeaponArt from '@/app/(protected)/(party)/components/WeaponArt'
import {
  describeBonuses,
  formatShare,
  formatStat,
  itemName,
  skillCost,
  skillName
} from '@/app/(protected)/(party)/utils/describe'
import GameButton from '@/app/components/GameButton'
import { useT } from '@/app/i18n/I18nProvider'
import type { MessageKey } from '@/app/i18n/messages'

/** The tabs of the page of a hero. */
export type HeroTab = 'status' | 'attributes' | 'weapons' | 'skills' | 'runes'

export const HERO_TABS: HeroTab[] = ['status', 'attributes', 'weapons', 'skills', 'runes']

interface HeroSheetProps {
  state: GameState
  character: CharacterState
  /** The part of the build shown. */
  tab: HeroTab
  atCamp: boolean
  /** The party stands on a cleared point: the weapons can be swapped. */
  canSwap: boolean
  onChange: (state: GameState) => void
}

const ATTRIBUTES: (keyof CombatStats)[] = [
  'maxHealth',
  'maxFocus',
  'attack',
  'special',
  'defense',
  'speed',
  'critChance',
  'critDamage'
]

/** The portrait of a hero (its bust, see `yarn art`). */
function portraitArtId(id: string): string {
  return `heroes/${id}/portrait`
}

/** One part of a hero: its state (portrait, bars and place in the formation), attributes, weapons, skills (loadout and tree) or runes and echoes. */
export default function HeroSheet({ state, character, tab, atCamp, canSwap, onChange }: HeroSheetProps) {
  const t = useT()
  const images = useArtImages()
  const id = character.id
  const name = t(`characters.${id}.name` as MessageKey)
  const position = state.characters.indexOf(character)
  const count = state.characters.length
  const active = position < ACTIVE_HEROES
  const portrait = portraitArtId(id)
  const { focus, maxFocus } = getFocus(character)
  const bars = [
    { kind: 'health', label: t('party.health'), value: character.health, max: getMaxHealth(character) },
    { kind: 'focus', label: t('party.focus'), value: focus, max: maxFocus },
    { kind: 'xp', label: t('party.experience'), value: character.xp, max: xpToNextLevel(character.level) }
  ]
  const stats = getCharacterStats(character)
  const attributePoints = getAttributePoints(character)
  const skillPoints = getSkillPoints(character)
  const spare = getKnownSkills(character).filter((skill) => !character.skills.includes(skill))
  const costOf = (skillId: string) => skillCost(skillId, Math.max(1, getSkillLevel(character, skillId)))

  return (
    <div className="hero-sheet">
      {tab === 'status' && (
        <section className="status">
          <h3>{t('party.status')}</h3>
          <div className="status-body">
            <div className={classNames('portrait', { fallen: character.health === 0 })}>
              {images[portrait] ? (
                <>
                  {/* eslint-disable-next-line @next/next/no-img-element -- the art is already a sized webp */}
                  <img src={artUrl(portrait)} alt="" draggable={false} />
                </>
              ) : (
                <span className="initial">{name.charAt(0)}</span>
              )}
            </div>
            <div className="details">
              <div className="titles">
                <span className="level">{t('world.level', { level: character.level })}</span>
                <span className={classNames('role', { reserve: !active })}>
                  {t(active ? 'party.active' : 'party.reserve')}
                </span>
              </div>
              <ul className="bars">
                {bars.map((bar) => (
                  <li key={bar.kind} className={bar.kind}>
                    <span className="label">{bar.label}</span>
                    <span className="track">
                      <span
                        className="fill"
                        style={{ width: `${Math.min(100, (bar.value / Math.max(1, bar.max)) * 100)}%` }}
                      />
                    </span>
                    <span className="value">
                      {bar.value}/{bar.max}
                    </span>
                  </li>
                ))}
              </ul>
              {count > 1 && (
                <div className="formation">
                  <span className="label">{t('party.formationPlace', { place: position + 1, total: count })}</span>
                  <Tooltip title={t('party.moveUp')}>
                    <span>
                      <IconButton
                        size="small"
                        disabled={position === 0}
                        aria-label={t('party.moveUp')}
                        onClick={() => onChange(moveInFormation(state, id, position - 1))}
                      >
                        <ChevronLeftIcon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                  <Tooltip title={t('party.moveDown')}>
                    <span>
                      <IconButton
                        size="small"
                        disabled={position === count - 1}
                        aria-label={t('party.moveDown')}
                        onClick={() => onChange(moveInFormation(state, id, position + 1))}
                      >
                        <ChevronRightIcon fontSize="small" />
                      </IconButton>
                    </span>
                  </Tooltip>
                </div>
              )}
            </div>
          </div>
          {count > ACTIVE_HEROES && <p className="lines formation-hint">{t('party.formationHint')}</p>}
        </section>
      )}

      {tab === 'attributes' && (
        <section>
          <h3>
            {t('party.attributes')}
            {attributePoints > 0 && <small>{t('party.attributePoints', { count: attributePoints })}</small>}
          </h3>
          <ul className="attributes">
            {ATTRIBUTES.map((stat) => (
              <li key={stat}>
                <span className="label">{t(`attributes.${stat}`)}</span>
                <span className="value">{formatStat(stat, stats[stat])}</span>
                <IconButton
                  size="small"
                  disabled={attributePoints <= 0}
                  aria-label={t('party.spendPoint', { stat: t(`attributes.${stat}`) })}
                  onClick={() => onChange(spendAttributePoint(state, id, stat))}
                >
                  <AddIcon fontSize="small" />
                </IconButton>
              </li>
            ))}
          </ul>
        </section>
      )}

      {tab === 'skills' && (
        <>
          <section>
            <h3>
              {t('party.battleSkills')}
              <small>
                {character.skills.length}/{SKILL_SLOTS}
              </small>
            </h3>
            <p className="lines">{t('party.battleSkillsHint', { count: SKILL_SLOTS })}</p>
            <ul className="loadout">
              {Array.from({ length: SKILL_SLOTS }, (_, index) => character.skills[index]).map((skillId, index) =>
                skillId ? (
                  <li key={skillId} className="slot">
                    <span className="badge">
                      <SkillIcon skillId={skillId} size="small" />
                      <span className="level">{getSkillLevel(character, skillId)}</span>
                    </span>
                    <span className="name">{skillName(t, skillId)}</span>
                    {costOf(skillId) > 0 && <span className="cost">{costOf(skillId)}</span>}
                    <IconButton
                      size="small"
                      aria-label={t('party.unequipSkill', { skill: skillName(t, skillId) })}
                      onClick={() => onChange(unequipSkill(state, id, skillId))}
                    >
                      <CloseIcon fontSize="small" />
                    </IconButton>
                  </li>
                ) : (
                  <li key={`empty-${index}`} className="slot empty">
                    {t('battle.emptySlot')}
                  </li>
                )
              )}
            </ul>
            {spare.length > 0 && (
              <>
                <h4 className="spare-title">{t('party.spareSkills')}</h4>
                <div className="spare">
                  {spare.map((skillId) => (
                    <ButtonBase
                      key={skillId}
                      className="spare-skill"
                      disabled={character.skills.length >= SKILL_SLOTS}
                      onClick={() => onChange(equipSkill(state, id, skillId))}
                    >
                      <SkillIcon skillId={skillId} size="small" />
                      {skillName(t, skillId)}
                      {costOf(skillId) > 0 && <span className="cost">{costOf(skillId)}</span>}
                    </ButtonBase>
                  ))}
                </div>
              </>
            )}
          </section>

          <section>
            <h3>
              {t('party.skills')}
              <small>{t('party.skillPoints', { count: Math.max(0, skillPoints) })}</small>
            </h3>
            <SkillTree state={state} character={character} onChange={onChange} />
            <div className="row">
              <span className="lines">{t('party.tears', { count: state.tears })}</span>
              <GameButton
                size="small"
                color="ghost"
                disabled={state.tears <= 0 || !canForgetSkills(character)}
                onClick={() => onChange(spendTear(state, id))}
              >
                {t('party.spendTear')}
              </GameButton>
            </div>
            {isTreeComplete(character) && (
              <div className="row">
                <span className="lines">{t('party.tradeHint')}</span>
                <GameButton
                  size="small"
                  color="magenta"
                  disabled={skillPoints <= 0}
                  onClick={() => onChange(tradeSkillPoint(state, id))}
                >
                  {t('party.trade', { count: TRADE_ECHOES })}
                </GameButton>
              </div>
            )}
          </section>
        </>
      )}

      {tab === 'weapons' && (
        <section>
          <h3>{t('party.weapons')}</h3>
          {!canSwap && <p className="lines">{t('party.swapOnly')}</p>}
          {!atCamp && <p className="lines">{t('party.upgradeCampOnly')}</p>}
          <ul className="cards weapons">
            {getCharacterWeapons(id)
              .filter((weapon) => weapon.id in character.weapons)
              .map((weapon) => {
                const held = weapon.id === character.weaponId
                const level = getWeaponLevel(character, weapon.id)
                const attack = getSkill(weapon.attack)
                const nextUpgrade = level < MAX_WEAPON_LEVEL ? getUpgradeCost(level + 1) : null
                const nextEffect = weapon.effects[Math.floor(level / 5)]
                const traits = describeBonuses(t, weapon.traits)

                return (
                  <li key={weapon.id} className={classNames({ worn: held })}>
                    <WeaponArt weapon={weapon} held={held} />
                    <div className="weapon-body">
                      <div className="titles">
                        <span className="name">
                          {t(`weapons.${weapon.id}.name` as MessageKey)}
                          {level > 0 && <span className="level">+{level}</span>}
                        </span>
                        {held && <span className="tag held">{t('party.weaponHeld')}</span>}
                      </div>
                      <p className="lines kind">{t(`weapons.${weapon.id}.kind` as MessageKey)}</p>
                      <p className="lines">
                        {t('party.weaponAttack', {
                          skill: skillName(t, attack.id),
                          type: t(`damageTypes.${attack.damageType}`),
                          target: t(`targets.${attack.target}`)
                        })}
                      </p>
                      <p className="lines">
                        {traits.length > 0
                          ? t('party.weaponStyle', { traits: traits.join(' · ') })
                          : t('party.weaponBalanced')}
                      </p>
                      <p className="lines">
                        {t('party.weaponPower', { value: formatShare(WEAPON_POWER_PER_LEVEL * level).slice(1) })}
                      </p>
                      {nextEffect && (
                        <p className="lines">
                          {t('party.weaponNext', {
                            level: (Math.floor(level / 5) + 1) * 5,
                            effect: describeBonuses(t, nextEffect).join(' · ')
                          })}
                        </p>
                      )}
                      {nextUpgrade ? (
                        <p className="lines">
                          {t('party.upgradeCost', {
                            stones: nextUpgrade.stones,
                            stone: itemName(t, nextUpgrade.stoneId),
                            gold: nextUpgrade.gold
                          })}
                          {' · '}
                          {t('party.have', { count: state.inventory[nextUpgrade.stoneId] ?? 0 })}
                        </p>
                      ) : (
                        <p className="lines">{t('party.weaponMax')}</p>
                      )}
                      <div className="actions">
                        {!held && (
                          <GameButton
                            size="small"
                            color="cyan"
                            disabled={!canSwap}
                            onClick={() => onChange(equipWeapon(state, id, weapon.id))}
                          >
                            {t('party.wield')}
                          </GameButton>
                        )}
                        {nextUpgrade && (
                          <GameButton
                            size="small"
                            disabled={!atCamp || !canUpgradeWeapon(state, character, weapon.id)}
                            onClick={() => onChange(upgradeWeapon(state, id, weapon.id))}
                          >
                            {t('party.upgrade', { level: level + 1 })}
                          </GameButton>
                        )}
                      </div>
                    </div>
                  </li>
                )
              })}
          </ul>
        </section>
      )}

      {tab === 'runes' && <RunesPanel state={state} character={character} atCamp={atCamp} onChange={onChange} />}
    </div>
  )
}
