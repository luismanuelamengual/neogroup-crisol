/** What a point of the world map is. */
export enum NodeType {
  /** A fight: it has to be won to go through. Its enemies come back every time the party rests. */
  COMBAT = 'combat',
  /** The starting camp (Glade of Awakening): the only one open from the beginning. */
  START = 'start',
  /** A boss that turns the point into a camp once defeated. */
  CAMP_BOSS = 'campBoss',
  /** A rune guarded by a mini boss or by an elite fight. */
  SANCTUARY = 'sanctuary',
  /** A safe point with a merchant, in a dead end right off a camp (no fight between them). */
  MERCHANT = 'merchant',
  /** A Tear of Oblivion (resets the skill points of a character), behind an elite fight. */
  TEAR = 'tear',
  /** A small chest in a dead end, free or guarded (see WorldNode.guarded). */
  CHEST = 'chest',
  /** An Amber Flask (one more charge of the flask), behind an elite fight. */
  AMBER_FLASK = 'amberFlask',
  /** An Amber Ember (the flask heals more), behind an elite fight. */
  AMBER_EMBER = 'amberEmber',
  /** A reliquary: a weapon of a character, guarded by a warden (only that character can claim it). */
  RELIQUARY = 'reliquary',
  /** The door of the Abyss: it opens once the three Seals are defeated. */
  ABYSS_GATE = 'abyssGate',
  /** Crisol, the final boss, in the castle of the Abyss. */
  FINAL_BOSS = 'finalBoss'
}
