import { SceneryDensity } from '@/app/(protected)/(engine)/data/scenery'
import { Biome } from '@/app/(protected)/(engine)/models/Biome'
import { NodeType } from '@/app/(protected)/(engine)/models/NodeType'
import { Terrain } from '@/app/(protected)/(engine)/models/Terrain'
import { Zone } from '@/app/(protected)/(engine)/models/Zone'

/**
 * The zones of a biome (see Zone): where they lie, their ground and how thick
 * their scenery grows. Their drawings are in the world map (sceneryTextures).
 */
export interface ZoneDefinition {
  zone: Zone
  biome: Biome
  /**
   * How often a stretch of the biome is of this zone, against the others and
   * against its plain look (BIOME_PLAIN_WEIGHT). A lair has none: it is only
   * around its captor (see LAIRS).
   */
  weight: number
  /** Its ground and patches, instead of the ones of the biome (BIOME_TERRAINS). */
  ground?: Terrain
  patches?: Terrain
  /** Its paved trails, instead of the biome's. */
  trail?: Terrain
  /** Its lakes, instead of the biome's, and how little noise makes one (lower: more lakes; see BiomeTerrains). */
  lake?: Terrain
  lakes?: number
  /** How little noise makes a patch, instead of the usual (lower: more of its patches; see PATCH_THRESHOLD in tileMap). */
  patchy?: number
  /** How thick its scenery grows, instead of the biome's (SCENERY_DENSITY). */
  density?: SceneryDensity
  /**
   * What closes it off: all along its edge a shore of this terrain, one tile
   * wide, and inside it a band of its lake this many tiles wide, crossed only
   * by the trails.
   */
  moat?: { shore: Terrain; width: number }
}

/** Weight of the plain look of a biome that has zones, against its zones. */
export const BIOME_PLAIN_WEIGHT = 3

export const ZONES: ZoneDefinition[] = [
  {
    zone: Zone.AUTUMN,
    biome: Biome.FOREST,
    weight: 2,
    patches: Terrain.LEAVES,
    density: { tall: 0.75, low: 0.26, ground: 1.6 }
  },
  {
    zone: Zone.PINEWOOD,
    biome: Biome.FOREST,
    weight: 2,
    patches: Terrain.NEEDLES,
    density: { tall: 1, low: 0.2, ground: 1.2 }
  },
  {
    zone: Zone.BLOSSOM,
    biome: Biome.FOREST,
    weight: 1.8,
    ground: Terrain.GRASS,
    patches: Terrain.MOSS,
    density: { tall: 0.5, low: 0.22, ground: 2.2 }
  },
  {
    zone: Zone.WITCHWOOD,
    biome: Biome.FOREST,
    weight: 0,
    ground: Terrain.BLIGHT,
    patches: Terrain.GLOOM,
    density: { tall: 0.8, low: 0.34, ground: 1.8 }
  },
  {
    zone: Zone.NECROPOLIS,
    biome: Biome.DESERT,
    weight: 0,
    ground: Terrain.REDSAND,
    patches: Terrain.DIRT,
    density: { tall: 0.5, low: 0.42, ground: 1.3 }
  },
  {
    zone: Zone.MARSH,
    biome: Biome.TROPICAL,
    weight: 1.5,
    ground: Terrain.MOSS,
    patches: Terrain.GRASS,
    density: { tall: 0.35, low: 0.42, ground: 1.6 }
  },
  {
    zone: Zone.DEEP_JUNGLE,
    biome: Biome.TROPICAL,
    weight: 2.2,
    ground: Terrain.MOSS,
    patches: Terrain.DIRT,
    density: { tall: 1, low: 0.34, ground: 2 }
  },
  {
    zone: Zone.PALM_GROVE,
    biome: Biome.TROPICAL,
    weight: 2,
    patches: Terrain.SAND,
    density: { tall: 0.55, low: 0.2, ground: 1.4 }
  },
  {
    zone: Zone.BAMBOO,
    biome: Biome.TROPICAL,
    weight: 2.3,
    patches: Terrain.NEEDLES,
    density: { tall: 0.95, low: 0.16, ground: 1.4 }
  },
  {
    zone: Zone.FLAMEWOOD,
    biome: Biome.TROPICAL,
    weight: 3.2,
    patches: Terrain.LEAVES,
    density: { tall: 0.7, low: 0.3, ground: 2.4 }
  },
  {
    zone: Zone.JADE_TEMPLE,
    biome: Biome.TROPICAL,
    weight: 0,
    ground: Terrain.JADEMOSS,
    patches: Terrain.MOSS,
    density: { tall: 0.6, low: 0.36, ground: 1.6 }
  },
  {
    zone: Zone.BASALT_HOLD,
    biome: Biome.MOUNTAINS,
    weight: 0,
    ground: Terrain.BASALT,
    patches: Terrain.ROCK,
    density: { tall: 0.45, low: 0.4, ground: 1.1 }
  },
  {
    zone: Zone.MIRE,
    biome: Biome.WASTELANDS,
    weight: 2.2,
    ground: Terrain.MUD,
    patches: Terrain.MOSS,
    lake: Terrain.MURK,
    lakes: 0.5,
    density: { tall: 0.5, low: 0.3, ground: 1.3 }
  },
  {
    zone: Zone.TOXIC,
    biome: Biome.WASTELANDS,
    weight: 2.2,
    ground: Terrain.BLIGHT,
    patches: Terrain.ASH,
    lake: Terrain.ACID,
    lakes: 0.5,
    density: { tall: 0.3, low: 0.34, ground: 1.1 }
  },
  {
    zone: Zone.THRESHOLD,
    biome: Biome.ABYSS,
    weight: 0,
    ground: Terrain.RUNESTONE,
    patches: Terrain.GLOOM,
    density: { tall: 0.12, low: 0.18, ground: 0.8 }
  },
  {
    zone: Zone.CRUCIBLE,
    biome: Biome.ABYSS,
    weight: 0,
    ground: Terrain.MAGMA,
    patches: Terrain.SCORCHED,
    trail: Terrain.FIRESTONE,
    lake: Terrain.LAVA,
    density: { tall: 0.22, low: 0.34, ground: 1.2 },
    moat: { shore: Terrain.BASALT, width: 2 }
  },
  {
    zone: Zone.FARMLAND,
    biome: Biome.MEADOWS,
    weight: 2,
    patches: Terrain.DIRT,
    patchy: 0.5,
    density: { tall: 0.14, low: 0.36, ground: 1.6 }
  },
  {
    zone: Zone.WILDFLOWERS,
    biome: Biome.MEADOWS,
    weight: 2,
    patches: Terrain.MOSS,
    density: { tall: 0.32, low: 0.3, ground: 3 }
  },
  {
    zone: Zone.HEATH,
    biome: Biome.MEADOWS,
    weight: 1.8,
    patches: Terrain.ROCK,
    patchy: 0.54,
    density: { tall: 0.16, low: 0.42, ground: 2 }
  },
  {
    zone: Zone.VILLAGE,
    biome: Biome.MEADOWS,
    weight: 0,
    density: { tall: 0.1, low: 0.08, ground: 2 }
  }
]

/**
 * The lair around the captor of a biome: its zone, how far it reaches from
 * the captor (world pixels, a little wobbly) and how far its ring of standing
 * stones (see the world map) stands.
 */
export interface LairDefinition {
  zone: Zone
  radius: number
}

export const LAIRS: Partial<Record<Biome, LairDefinition>> = {
  [Biome.FOREST]: { zone: Zone.WITCHWOOD, radius: 1000 },
  [Biome.DESERT]: { zone: Zone.NECROPOLIS, radius: 1150 },
  [Biome.TROPICAL]: { zone: Zone.JADE_TEMPLE, radius: 1150 },
  [Biome.MOUNTAINS]: { zone: Zone.BASALT_HOLD, radius: 1150 }
}

/** The zones around the door of the Abyss and around Crisol (see WorldAbyss in the world map). */
export const ABYSS_PLACES: Partial<Record<NodeType, LairDefinition>> = {
  [NodeType.ABYSS_GATE]: { zone: Zone.THRESHOLD, radius: 620 },
  [NodeType.FINAL_BOSS]: { zone: Zone.CRUCIBLE, radius: 1050 }
}

/**
 * The village around the merchant of a biome (see placeVillages): its zone,
 * how far it reaches from the merchant (world pixels, a little wobbly) and
 * how many cottages it has at most.
 */
export interface VillageDefinition {
  zone: Zone
  radius: number
  houses: number
}

export const VILLAGES: Partial<Record<Biome, VillageDefinition>> = {
  [Biome.MEADOWS]: { zone: Zone.VILLAGE, radius: 850, houses: 12 }
}

/** Every zone, in the order TileMap.zones refers to them (0 is none, 1 the first one...). */
export const ZONES_ORDER = ZONES.map(({ zone }) => zone)

export function getZoneDefinition(zone: Zone): ZoneDefinition {
  return ZONES.find((definition) => definition.zone === zone)!
}
