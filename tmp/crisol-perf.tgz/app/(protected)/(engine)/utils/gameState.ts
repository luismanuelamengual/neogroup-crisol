import { getBaseStats, getCharacterDefinition } from '@/app/(protected)/(engine)/data/characters'
import { FLASK_BASE_CHARGES } from '@/app/(protected)/(engine)/data/flask'
import { RUNE_COUNT } from '@/app/(protected)/(engine)/data/runes'
import { getSkillTree, MAX_SKILL_LEVEL } from '@/app/(protected)/(engine)/data/skillTrees'
import { getStartingWeapon, MAX_WEAPON_LEVEL, WEAPONS } from '@/app/(protected)/(engine)/data/weapons'
import { START_NODE_ID } from '@/app/(protected)/(engine)/data/world'
import { CharacterId } from '@/app/(protected)/(engine)/models/CharacterId'
import { CharacterState } from '@/app/(protected)/(engine)/models/CharacterState'
import { GameState } from '@/app/(protected)/(engine)/models/GameState'
import { createCharacter, getKnownSkills, SKILL_SLOTS } from '@/app/(protected)/(engine)/utils/heroes'

/** Version of the shape of GameState (see `saves.saveVersion`). */
export const SAVE_VERSION = 13

/**
 * The six runes added with world 40 (wisdom, tribute, clover, vigil, patient
 * apprentice and respite) took their places in the order of power: after these indices
 * of the old order. Their points were fights before.
 */
const V13_RUNES_AFTER = [6, 14, 24, 33, 49, 60]
const V13_RUNE_NODES = ['n850', 'n820', 'n494', 'n569', 'n3', 'n275']

/** State of a brand new game: Kael alone, at level 1, in the starting camp. */
export function createInitialGameState(gameId: string = crypto.randomUUID()): GameState {
  return {
    gameId,
    cycle: 0,
    positionNodeId: START_NODE_ID,
    lastRestCampId: START_NODE_ID,
    openCampIds: [START_NODE_ID],
    clearedNodeIds: [START_NODE_ID],
    respawnedNodeIds: [],
    restsSinceCleared: {},
    lostXp: null,
    flaskCharges: FLASK_BASE_CHARGES,
    characters: [createCharacter(CharacterId.KAEL)],
    gold: 0,
    kills: {},
    inventory: {},
    runes: [],
    runeWins: {},
    tears: 0,
    echoes: 0,
    scholarSold: 0
  }
}

/**
 * Brings a state saved with an older SAVE_VERSION to the current shape. Each
 * step migrates one version, so a very old save goes through all of them.
 */
export function migrateGameState(data: unknown, fromVersion: number): unknown {
  let state = data as Record<string, unknown>

  if (fromVersion < 2) {
    // v2: game id, respawned fights, Amber Flask and the health of the characters.
    state = {
      ...state,
      gameId: 'legacy',
      respawnedNodeIds: [],
      flaskCharges: FLASK_BASE_CHARGES,
      characters: ((state.characters ?? []) as Omit<CharacterState, 'health'>[]).map((character) => ({
        ...character,
        health: Math.round(getBaseStats(character.id, character.level).maxHealth)
      }))
    }
  }

  if (fromVersion < 3) {
    // v3: enemies defeated, for the bestiary.
    state = { ...state, kills: {} }
  }

  if (fromVersion < 4) {
    // v4: builds (points, trees, weapons, runes, echoes), inventory, runes and Echoes. The points and the
    // Echoes of the levels already gained are there to spend.
    const characters = (state.characters ?? []) as Pick<CharacterState, 'id' | 'level' | 'xp' | 'health'>[]

    state = {
      ...state,
      characters: characters.map((character) => ({
        ...character,
        attributes: {},
        talents: [],
        traded: 0,
        weapon: 0,
        runes: [],
        echoCapacity: 0,
        echoes: []
      })),
      inventory: {},
      runes: [],
      runeWins: {},
      tears: 0,
      echoes: characters.reduce((sum, character) => sum + character.level - 1, 0),
      scholarSold: 0
    }
  }

  if (fromVersion < 5) {
    // v5: three weapons per character. The upgrade it had goes to the weapon it starts with, which it holds.
    state = {
      ...state,
      characters: (
        (state.characters ?? []) as (Omit<CharacterState, 'weaponId' | 'weapons'> & { weapon?: number })[]
      ).map(({ weapon, ...character }) => {
        const starting = getStartingWeapon(character.id).id

        return { ...character, weaponId: starting, weapons: { [starting]: weapon ?? 0 } }
      })
    }
  }

  if (fromVersion < 6) {
    // v6: Oren wields sickles and scythes and Ysolde grimoires (the weapons that were staves, scepters and a wand).
    const renamed: Record<string, string> = {
      'grove-staff': 'root-sickle',
      'sun-scepter': 'noon-scythe',
      'crystal-staff': 'trinity-tome',
      'storm-scepter': 'thunder-codex',
      'prism-wand': 'dusk-grimoire'
    }
    const rename = (id: string) => renamed[id] ?? id

    state = {
      ...state,
      characters: ((state.characters ?? []) as CharacterState[]).map((character) => ({
        ...character,
        weaponId: rename(character.weaponId),
        weapons: Object.fromEntries(Object.entries(character.weapons).map(([id, level]) => [rename(id), level]))
      }))
    }
  }

  if (fromVersion < 7) {
    // v7: up to six skills equipped for battle. The special it starts with is equipped (v11 rebuilds the trees,
    // so the specials of the old ones do not matter).
    state = {
      ...state,
      characters: ((state.characters ?? []) as Omit<CharacterState, 'skills'>[]).map((character) => ({
        ...character,
        skills: getCharacterDefinition(character.id).skills.slice(1, 2)
      }))
    }
  }

  if (fromVersion < 8) {
    // v8: Kael's change of stance is a secondary action, out of the six slots.
    state = {
      ...state,
      characters: ((state.characters ?? []) as CharacterState[]).map((character) => ({
        ...character,
        skills: character.skills.filter((skill) => skill !== 'kael-stance')
      }))
    }
  }

  if (fromVersion < 9) {
    // v9: the enemies of a common fight come back after three rests, not after one. The fights won count from
    // zero; the ones already back stay back.
    state = { ...state, restsSinceCleared: {} }
  }

  if (fromVersion < 10) {
    // v10: the experience lost in a defeat waits where the party fell. Nothing is waiting yet.
    state = { ...state, lostXp: null }
  }

  if (fromVersion < 11) {
    // v11: skill trees of specials with levels, one per row, and no passives. Every skill point spent comes back
    // to spend again; the specials it keeps are the one it starts with.
    state = {
      ...state,
      characters: ((state.characters ?? []) as (CharacterState & { talents?: string[] })[]).map(
        ({ talents: _talents, ...character }) => {
          const reset = { ...character, skillLevels: { [getSkillTree(character.id).root]: 1 } }
          const known = getKnownSkills(reset)

          return { ...reset, skills: character.skills.filter((skill) => known.includes(skill)) }
        }
      )
    }
  }

  if (fromVersion < 12) {
    // v12: all of Sera's weapons are bows (the frost crossbow is a frost longbow).
    const rename = (id: string) => (id === 'frost-crossbow' ? 'frost-longbow' : id)

    state = {
      ...state,
      characters: ((state.characters ?? []) as CharacterState[]).map((character) => ({
        ...character,
        weaponId: rename(character.weaponId),
        weapons: Object.fromEntries(Object.entries(character.weapons).map(([id, level]) => [rename(id), level]))
      }))
    }
  }

  if (fromVersion < 13) {
    // v13: six new runes. The ones after them in the order of power move up their index (owned, equipped, worn as
    // echoes and their wins); their points, if won as fights, wait to be won again as sanctuaries (unless the
    // party stands there).
    const shift = (index: number) => index + V13_RUNES_AFTER.filter((after) => index > after).length
    const reopened = V13_RUNE_NODES.filter((id) => id !== state.positionNodeId)
    const keep = (id: string) => !reopened.includes(id)

    state = {
      ...state,
      runes: ((state.runes ?? []) as number[]).map(shift),
      runeWins: Object.fromEntries(
        Object.entries((state.runeWins ?? {}) as Record<string, number>).map(([index, wins]) => [
          shift(Number(index)),
          wins
        ])
      ),
      clearedNodeIds: ((state.clearedNodeIds ?? []) as string[]).filter(keep),
      respawnedNodeIds: ((state.respawnedNodeIds ?? []) as string[]).filter(keep),
      restsSinceCleared: Object.fromEntries(
        Object.entries((state.restsSinceCleared ?? {}) as Record<string, number>).filter(([id]) => keep(id))
      ),
      characters: ((state.characters ?? []) as CharacterState[]).map((character) => ({
        ...character,
        runes: character.runes.map(shift),
        echoes: character.echoes.map(shift)
      }))
    }
  }

  return state
}

/** Whether a value has the shape of a GameState (what the server checks before storing a save). */
export function isGameState(value: unknown): value is GameState {
  if (!value || typeof value !== 'object') {
    return false
  }

  const state = value as Record<string, unknown>
  const isStringArray = (item: unknown) => Array.isArray(item) && item.every((entry) => typeof entry === 'string')
  const isCount = (item: unknown) => Number.isInteger(item) && (item as number) >= 0
  const isCountMap = (item: unknown) =>
    !!item && typeof item === 'object' && !Array.isArray(item) && Object.values(item).every(isCount)
  const isRuneIndex = (item: unknown) =>
    Number.isInteger(item) && (item as number) >= 1 && (item as number) <= RUNE_COUNT
  const characterIds = Object.values(CharacterId) as string[]
  // Nothing waiting, or a point with what each character lost there.
  const isLostXp = (item: unknown) =>
    item === null ||
    (!!item &&
      typeof item === 'object' &&
      typeof (item as Record<string, unknown>).nodeId === 'string' &&
      isCountMap((item as Record<string, unknown>).xp) &&
      Object.keys((item as Record<string, object>).xp).every((id) => characterIds.includes(id)))
  // The weapons of a character: its own, with an upgrade from 0 to the maximum.
  const isWeaponsOf = (id: unknown, item: unknown) =>
    isCountMap(item) &&
    Object.entries(item as Record<string, number>).every(
      ([weaponId, level]) =>
        WEAPONS.some((weapon) => weapon.id === weaponId && weapon.characterId === id) && level <= MAX_WEAPON_LEVEL
    )

  return (
    typeof state.gameId === 'string' &&
    isCount(state.cycle) &&
    typeof state.positionNodeId === 'string' &&
    typeof state.lastRestCampId === 'string' &&
    isStringArray(state.openCampIds) &&
    isStringArray(state.clearedNodeIds) &&
    isStringArray(state.respawnedNodeIds) &&
    isCountMap(state.restsSinceCleared) &&
    isLostXp(state.lostXp) &&
    isCount(state.flaskCharges) &&
    isCount(state.gold) &&
    isCount(state.tears) &&
    isCount(state.echoes) &&
    isCount(state.scholarSold) &&
    isCountMap(state.inventory) &&
    isCountMap(state.runeWins) &&
    Array.isArray(state.runes) &&
    state.runes.every(isRuneIndex) &&
    isCountMap(state.kills) &&
    Array.isArray(state.characters) &&
    state.characters.length > 0 &&
    state.characters.every((character) => {
      const {
        id,
        level,
        xp,
        health,
        focus,
        attributes,
        skillLevels,
        traded,
        skills,
        weaponId,
        weapons,
        runes,
        echoCapacity,
        echoes
      } = (character ?? {}) as Record<string, unknown>

      return (
        characterIds.includes(id as string) &&
        Number.isInteger(level) &&
        (level as number) >= 1 &&
        isCount(xp) &&
        isCount(health) &&
        (focus === undefined || isCount(focus)) &&
        isCountMap(attributes) &&
        isCountMap(skillLevels) &&
        Object.values(skillLevels as Record<string, number>).every((level) => level >= 1 && level <= MAX_SKILL_LEVEL) &&
        isCount(traded) &&
        isStringArray(skills) &&
        (skills as string[]).length <= SKILL_SLOTS &&
        new Set(skills as string[]).size === (skills as string[]).length &&
        isWeaponsOf(id, weapons) &&
        typeof weaponId === 'string' &&
        weaponId in (weapons as Record<string, number>) &&
        Array.isArray(runes) &&
        runes.length <= 3 &&
        runes.every(isRuneIndex) &&
        isCount(echoCapacity) &&
        Array.isArray(echoes) &&
        echoes.every(isRuneIndex)
      )
    })
  )
}
